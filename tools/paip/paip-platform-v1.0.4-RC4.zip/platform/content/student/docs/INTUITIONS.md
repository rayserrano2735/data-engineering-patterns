# PAIP Student Intuitions
**Version:** 1.0.4-RC3

This document captures student insights about confusing or counterintuitive Python syntax, with SQL mappings and design evaluations.

## Purpose

When you encounter something confusing:
1. Document what confused you
2. Articulate your initial understanding
3. Record the resolved explanation
4. Evaluate whether the design choice is good
5. Map to SQL intuition where applicable

---

## List Comprehension Order

**Confusion:** Syntax order (result, loop, filter) doesn't match execution order (loop, filter, result)

**Initial Understanding:**
"There are three elements: loop, selection criteria, results. Logically we execute: loop → filter → collect. But Python writes it backwards: collect → loop → filter."

**SQL Mapping:**
```python
# Python (backwards from execution)
[n for n in numbers if n % 2 == 0]

# SQL (matches execution order)
SELECT n 
FROM numbers 
WHERE n % 2 = 0
```

**Design Rationale:** Python's syntax mimics set-builder notation from mathematics: {x² | x ∈ numbers, x even}

**Design Evaluation:** Poor choice for a procedural programming language. Math notation optimization conflicts with execution model - creates unnecessary cognitive load for programmers thinking in terms of loops and filters.

**Why This Gets Tested:** Interviewers weaponize counterintuitive syntax. This backwards pattern is a common gatekeeping question.

**Interview Strategy:** Explain both the syntax order AND execution order to show you understand the distinction.

---

## Template for New Intuitions

**Confusion:** [What confused you]

**Initial Understanding:** [How you first tried to understand it]

**SQL Mapping:** [If applicable, show SQL equivalent]

**Design Rationale:** [Why Python/pandas made this choice]

**Design Evaluation:** [Is this a good design choice? Why/why not?]

**Why This Gets Tested:** [Why interviewers ask about this]

**Interview Strategy:** [How to handle this in interviews]

