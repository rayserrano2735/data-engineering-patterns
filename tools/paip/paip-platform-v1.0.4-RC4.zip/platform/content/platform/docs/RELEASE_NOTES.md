# Release Notes

## v1.0.4-RC3 (Current)

**Released:** October 7, 2025
**Status:** In QA Testing

### RC1 Rejection

**Reason:** Installer referenced wrong zip filename (v1.0.4-RC3.zip instead of v1.0.4-RC1.zip)

### RC2 Changes

**Week 2 Day 1 - Modern Python Patterns:**
- Added 1-hour content bridging Python fundamentals to production patterns
- Decorators: Functions as objects, closures, @ syntax explanation (45 min)
- Flexible arguments: *args/**kwargs with SQL analogies (included in decorator section)
- Orchestration concepts: Task dependencies, orchestration vs transformation (15 min)
- Extracted from zero_to_decorators.py and airflow materials

**Pattern Library Expansion:**
- Added Pattern 30: Orchestration Task Dependencies to Category 9
- Real Airflow examples: sequential, parallel convergence, sensors
- Interview talking points for workflow coordination questions

**Documentation Fixes:**
- Fixed PLATFORM_ARCHITECTURE.md flashcard count (50 → 74)
- Added handover efficiency guidance to DEVELOPMENT_PROCESS.md
- Added unit testing mandate: "Dev owns testing - test everything testable"

**Installer Fix:**
- Corrected zip filename reference to v1.0.4-RC3.zip
- Added unit test for version consistency across installer and docs

### Files Modified
- PAIP_TEXTBOOK.md - Added Week 2 Day 1 content (decorators, orchestration)
- LEARNING_GUIDE.md - Added Pattern 30
- PLATFORM_ARCHITECTURE.md - Fixed flashcard count
- DEVELOPMENT_PROCESS.md - Added testing mandate, handover guidance
- ROADMAP.md - Moved RC1 to rejected, added RC2 in progress
- All docs - Updated version to 1.0.4-RC3

### Breaking Changes
None

---

## v1.0.4-RC1 (Rejected)

**Released:** October 7, 2025
**Status:** Rejected - Installer filename mismatch
**Rejection Reason:** Installer referenced v1.0.4-RC3.zip instead of v1.0.4-RC1.zip

### Major Changes

**Content Order & Confusion Framework:**
- Created INTUITIONS.md template capturing counterintuitive syntax with SQL mappings
- Added list comprehension deep-dive: execution vs syntax order, design evaluation, bracket types
- Added Essential Built-in Functions section (list, range, evaluation) before examples
- Clarified "ordered" (position preserved) vs "sorted" (arranged by value)
- Fixed content dependency violations (concepts introduced before use)

**Quick Reference Enhancements:**
- Added result examples to all operations (e.g., `lst.append(4)  # [1, 2, 3, 4]`)
- Students can verify syntax without running code

**Flashcard Completeness:**
- Expanded from 50 to 74 flashcards (+24)
- Added comprehensive method coverage: list/dict/set/string operations
- Covers insert, remove, pop, setdefault, update, discard, find, enumerate, zip, filter, map

**Wing IDE Integration:**
- Documented Git integration in GETTING_STARTED.md
- Source Control panel, diff view, commit UI
- Students can commit work without leaving IDE

**Process Improvements:**
- Token budget tracking with 80%/90% alerts
- Backlog refinement process documentation
- Build token cost reporting (this build: 2,005 tokens)

### User Stories Completed

1. **Content Order & Confusion Framework** (Large) - Fixed dependency violations, added confusion explanations
2. **Quick Reference Enhancements** (Small) - Result examples, ordered vs sorted
3. **Flashcard Completeness** (Small) - 24 new method cards
4. **Wing IDE Integration** (Small) - Git integration documented
5. **Process Improvements** (Small) - Token tracking, backlog refinement

### Files Added
- `/platform/content/docs/INTUITIONS.md` - Student insights template

### Files Modified
- PAIP_TEXTBOOK.md - Added built-in functions, comprehension deep-dive, ordered/sorted clarity
- quick_reference.md - Added result examples to all operations
- week1_flashcards.txt - Added 24 method flashcards (total 74)
- GETTING_STARTED.md - Wing Git integration section
- DEVELOPMENT_PROCESS.md - Token tracking, backlog refinement sections

### Breaking Changes
None

---

## v1.0.3 (Released)

**Released:** October 6, 2025

Testing infrastructure and content refinements with TDD structure.

**Key Features:**
- TDD structure: stubs, test harness, solutions
- 29 patterns (24 data + 5 testing)
- Python Prerequisites section
- 50 flashcards
- Extended thinking + voice mode for Interview Mode

---

## v1.0.2 (Released)

Week 1 foundation content with textbook and pattern library.

---

## v1.0.1 (Released)

Development environment with Wing IDE integration.

