"""Platform content package."""
