# Release Notes

## v1.0.1-RC12 (Current)

**Released:** October 5, 2025

### Critical Fix

**Bootstrap Profile Update:**
- Fixed bootstrap to ALWAYS regenerate PowerShell/Bash profile entries
- Removes all old PAIP-related lines before adding new configuration
- No early return if existing config detected
- Ensures new environment variables (PYTHONPATH) get written

**Why This Matters:**
- RC11 bootstrap detected old config and skipped update
- Profile had PAIP_HOME but no PYTHONPATH
- Bootstrap claimed success but PYTHONPATH never written
- Now always regenerates to ensure current version

### From RC11 (All Fixes Carried Forward)
- PYTHONPATH in profiles and .wpu
- .gitignore configuration
- __init__.py files
- Unit tested approach

### QA Notes
- After installation, restart terminal
- Verify `$env:PYTHONPATH` is set in PowerShell
- Verify imports work in Wing IDE

---

## v1.0.1-RC11 (Rejected)

**Released:** October 5, 2025
**Status:** Failed QA

### Why Rejected
- Bootstrap said "PowerShell profile already configured" and skipped update
- **ROOT CAUSE:** Early return logic (lines 134-136) if PAIP_HOME found
- Profile had old configuration without PYTHONPATH
- PYTHONPATH never written despite bootstrap reporting success

---

## v1.0.1-RC10 (Rejected)

**Released:** October 5, 2025
**Status:** Failed QA

### Why Rejected
- Imports still failed despite __init__.py files present
- **ROOT CAUSE:** proj.pypath in .wpr only affects IDE features (autocomplete), not Python runtime execution
- Missing PYTHONPATH environment variable for actual imports
- .gitignore excluded .wpr files (should be tracked)

---

## v1.0.1-RC9 (Rejected)

**Released:** October 5, 2025
**Status:** Failed QA

### Why Rejected
- Import still failed despite proj.pypath being correct in .wpr
- **ROOT CAUSE:** Missing __init__.py in platform/content/src/ - Python requires this file to treat directories as packages
- .gitignore incorrectly excluded study/ content, preventing student work from being tracked

---

## v1.0.1-RC8 (Rejected)

**Released:** October 5, 2025
**Status:** Failed QA

### Why Rejected
- Installer prompts not visible - logging redirection captured interactive input
- **CRITICAL:** Bootstrap .wpr generation bug - f-string formatting issue caused proj.pypath lines not to be written
- Imports failed: `from src.patterns_and_gotchas import CorePatterns` → ModuleNotFoundError
- Bootstrap reported success but .wpr file was incomplete

---

## v1.0.1-RC7

**Released:** October 4, 2025
**Status:** Rolled back - QA incomplete

### Fixes
- PowerShell $PROFILE detection works with OneDrive
- All Unicode emoji removed from bootstrap
- Install log created (bootstrap output only)

### Blockers
- Platform content not importable (no PYTHONPATH in .wpr)
- Imports failed in Wing IDE
- Debugging untested due to import issue

---

## v1.0.1 (Target)

**Development Environment Improvements:**

**User-Level Virtual Environment:**
- venv now created at `~/.venvs/paip` instead of repo root
- Survives git clean operations
- Can be shared across multiple repo clones
- Cleaner repository structure

**Wing IDE Auto-Configuration:**
- Bootstrap generates .wpr (project file) automatically
- Bootstrap generates .wpu (user preferences) with correct Python interpreter
- Proper source path configuration (platform/content in PYTHONPATH)
- Exclusions for faster IDE performance
- No manual Wing setup required

**Platform:**
- `requirements.txt` now at repository root (standard location)
- Updated `.gitignore` for Wing backup files (*.wpr~, .wingide/)
- Improved bootstrap automation
- PAIP_HOME environment variable

**Documentation:**
- Complete GETTING_STARTED.md rewrite for automated setup
- ROADMAP.md added for feature planning
- Platform architecture updated with user-level venv rationale
- Version headers on all documentation

---

## v1.0.0

**Released:** October 3, 2025

### First Complete Release

**Content:**
- 60 exercises across 6 modules (exercises.py)
- 20+ core pandas patterns library (patterns_and_gotchas.py)
- 8-week curriculum with schedule
- 60 interview flashcards
- Complete documentation suite

**Documentation:**
- Platform architecture guide
- Getting started guide
- Course with schedule
- Quick reference
- Talking points
- Learning guide
- Release notes

**Platform:**
- Bootstrap automation script
- Installer with artifact cleanup
- Git autocrlf configuration
- Version control copy feature

**Structure:**
```
platform/
  tools/       - Bootstrap, Docker placeholder
  content/
    src/       - Exercises and patterns (populated)
    docs/      - Full documentation (7 files)
    patterns/  - Pattern library (8 files)
    data/      - Flashcards
study/         - User workspace
```

---

## v0.6.3

**Released:** October 3, 2025

### New Features
- Content subdirectories with .gitkeep files (src/, docs/, patterns/, data/)
- Artifact cleanup for brace-expansion folders
- Installation confirmation prompt

### Bug Fixes
- Fixed study folder zip artifact
- Fixed content folder zip artifacts
- Install script now removes unexpected subdirectories

### Improvements
- Complete platform/ folder replacement (no merge)
- CRLF warnings eliminated (autocrlf=false)
- Cleaner installation process

---

## Upgrade Path

### From v1.0.1-RC7 to RC8
- Download RC8 installer and zip
- Run installer
- Bootstrap now fixes Wing PYTHONPATH
- Imports will work automatically

### From v0.5.x to v1.0.1
- Download v1.0.1 installer and zip
- Run installer (auto-detects old structure)
- Old files moved to Downloads/paip-rollback-[date]
- study/ workspace preserved
- Bootstrap runs automatically

---

## Known Issues

### RC8
- None currently

### All Versions
- Bootstrap requires terminal restart to activate environment variables
- Virtual environment must be manually activated before use

---

## Future Releases

### Planned for v1.1.0
- Active learning: Pattern recognition drills
- Timed problem solving practice
- Progress tracking

### Under Consideration
- Automated testing framework
- GitHub Releases integration
- Docker environment
