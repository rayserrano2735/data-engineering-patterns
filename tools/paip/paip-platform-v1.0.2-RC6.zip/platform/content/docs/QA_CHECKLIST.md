# QA Checklist
**Version:** 1.0.2-RC6

This document maintains testing criteria for each PAIP release. Each version includes both regression tests (features from previous versions) and new feature validation.

---

## v1.0.2-RC6 - Week 1 Foundation Content

### Installation
- [ ] Run installer (silent mode)
- [ ] Check install.log for full output
- [ ] Verify git repo initialized

### Bootstrap Execution  
- [ ] Verify bootstrap ran successfully
- [ ] **CRITICAL:** Check install.log shows "Updated PowerShell profile" (NOT "already configured")
- [ ] Check venv exists at `~/.venvs/paip`

### PowerShell Profile Verification (THE CRITICAL TEST)
- [ ] **CRITICAL:** Open PowerShell profile: `notepad $PROFILE`
- [ ] Verify it contains ALL these lines:
  - [ ] `# Python Interview Prep Environment (auto-generated)`
  - [ ] `$env:GITHUB_HOME = "..."`
  - [ ] `$env:PAIP_HOME = "..."`
  - [ ] `$env:PYTHONPATH = "...\platform\content"`
  - [ ] `$env:PATTERNS_REPO = "..."`
  - [ ] `$env:PATTERNS_TOOLS = "..."`
  - [ ] `$env:PATH = "..."`
- [ ] Verify NO duplicate PAIP entries in profile

### Environment Variables (After Terminal Restart)
- [ ] **Restart PowerShell completely**
- [ ] Run: `echo $env:PYTHONPATH`
- [ ] **CRITICAL:** Should show path ending in `\platform\content`
- [ ] Verify other vars: GITHUB_HOME, PAIP_HOME, PATTERNS_REPO, PATTERNS_TOOLS

### Wing IDE Configuration
- [ ] Verify .wpu file has ONLY `proj.pyexec` (no proj.env-vars)
- [ ] Verify .wpr file contains proj.pypath line
- [ ] **CRITICAL:** Check desktop for "PAIP - Wing IDE" shortcut
- [ ] Double-click desktop shortcut - Wing should launch with project
- [ ] Alternative: Open new PowerShell, run `Open-Wing` command
- [ ] Wing should start Python shell successfully
- [ ] Test in Python shell: `import sys; print(sys.path)`
- [ ] Verify platform/content path in sys.path

### Import Testing
- [ ] Close and reopen Wing IDE
- [ ] Create test in study/practice_work/: `from src.patterns_and_gotchas import CorePatterns`
- [ ] **CRITICAL:** Run - should execute without ModuleNotFoundError
- [ ] Test: `from src.exercises import exercise_1_1`

### Week 1 Content Verification
- [ ] Verify PAIP_TEXTBOOK.md exists in platform/content/docs/ (UPPERCASE filename)
- [ ] Verify Week 1 section is complete (7 hours content)
- [ ] Verify Interview Mode practice section exists in PAIP_TEXTBOOK.md
- [ ] Verify week1_exercises.py exists in platform/content/src/
- [ ] Run: `python platform/content/src/week1_exercises.py` - all exercises should pass
- [ ] Verify week1_flashcards.txt exists in platform/content/data/
- [ ] Verify INTERVIEW_MODE_WEEK1.md exists in platform/content/docs/
- [ ] Verify LEARNING_GUIDE.md contains Interview Mode section with framework for creating IM docs
- [ ] Verify quick_reference.md exists in platform/content/docs/
- [ ] Verify talking_points.md exists in platform/content/docs/
- [ ] Verify course_with_schedule.md exists (legacy, unchanged)

### Git Configuration
- [ ] Create test file in study/practice_work/
- [ ] Run `git status` - file should appear
- [ ] Verify .wpr tracked, .wpu ignored

### QA Certification
**After ALL checklist items pass:**
- [ ] Git operations:
  ```
  git add platform/ .gitignore README.md requirements.txt activate_env.txt study/
  git add python-analytics-interview-prep.wpr
  git commit -m "Platform v1.0.2-RC6"
  git tag -a v1.0.2 -m "Release v1.0.2"
  ```

---

## v1.0.2-RC6 - Week 1 Foundation Content (Rejected)

**Why Rejected:**
- QA_CHECKLIST.md had duplicate RC5 sections due to global sed replacement
- QA_CHECKLIST.md historical RC labels incorrect (sed changed all RC3/RC4 to RC5)

### Changes Made in RC5:
- ✅ Renamed paip_textbook.md → PAIP_TEXTBOOK.md
- ✅ Added Interview Mode schedule to PAIP_TEXTBOOK.md
- ✅ Added Interview Mode framework to LEARNING_GUIDE.md

---

## v1.0.2-RC4 - Week 1 Foundation Content (Rejected)

**Why Rejected:**
- Textbook filename should be uppercase
- Interview Mode not integrated into textbook learning schedule
- Interview Mode framework missing from LEARNING_GUIDE.md

### Changes Made in RC4:
- ✅ Fixed QA_CHECKLIST.md historical section headers
- ✅ Added missing RC1 rejected section
- ✅ Added UNIT_TEST_CHECKLIST.md to version control copy

---

## v1.0.2-RC3 - Week 1 Foundation Content (Rejected)

**Why Rejected:**
- QA_CHECKLIST.md historical sections had wrong labels
- QA_CHECKLIST.md missing RC1 rejected section

### Changes Made in RC3:
- ✅ Added RC3 section to QA_CHECKLIST.md
- ✅ Updated installer version numbers

---

## v1.0.2-RC2 - Week 1 Foundation Content (Rejected)

**Why Rejected:**
- Installer had wrong version numbers
- QA_CHECKLIST.md historical sections overwritten

---

## v1.0.2-RC1 - Week 1 Foundation Content (Rejected)

**Why Rejected:**
- Missing paip_textbook.md
- Missing LEARNING_GUIDE.md with 24-pattern documentation
- Missing week1_exercises.py, week1_flashcards.txt, INTERVIEW_MODE_WEEK1.md
- Missing restored docs

---

## v1.0.1 - Development Environment Setup (Released)

Complete development environment with Wing IDE integration, desktop shortcuts, and git tracking.

### Installation
- [x] Automated bootstrap with PowerShell profile configuration
- [x] Wing IDE integration with desktop shortcut
- [x] Git tracking for study/ workspace
- [x] PYTHONPATH configuration for imports
- [x] Open-Wing PowerShell function

---

## v1.0.0 - Initial Complete Release

Platform foundation with basic structure and tooling.
