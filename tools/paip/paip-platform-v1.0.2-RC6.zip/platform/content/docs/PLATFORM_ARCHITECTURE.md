# Platform Architecture
**Version: 1.0.2-RC6

## Overview

Two-tier structure separating platform infrastructure from user workspace, with user-level virtual environment and automated IDE configuration.

## Directory Structure

```
python-analytics-interview-prep/
├── platform/
│   ├── tools/                # Platform infrastructure
│   │   ├── bootstrap.py      # Environment automation + Wing setup
│   │   └── docker/           # Docker setup (placeholder)
│   └── content/              # Learning materials
│       ├── src/              # Python exercises and patterns
│       ├── docs/             # Curriculum and guides
│       ├── patterns/         # Pattern library
│       └── data/             # Flashcards and datasets
├── study/                    # User workspace (not tracked)
│   ├── practice_work/
│   ├── notes/
│   └── mock_interviews/
├── requirements.txt          # Python dependencies (root level)
├── .gitignore               # Git exclusions
└── python-analytics-interview-prep.wpr  # Wing IDE project (generated)

User-level:
~/.venvs/paip/               # Virtual environment (outside repo)
```

## Design Principles

### Separation of Concerns
- **tools/**: Platform setup, versioning, installation scripts
- **content/**: Learning materials organized by type
- **study/**: User workspace, never overwritten
- **~/.venvs/paip**: Virtual environment, separate from repo

### User-Level Virtual Environment (v1.0.1)
**Location:** `~/.venvs/paip`

**Rationale:**
- Survives `git clean -fdx` and other destructive git operations
- One venv can serve multiple repo clones (if needed)
- Keeps repo directory clean and focused
- Standard Python tooling (poetry, pipenv) uses similar convention
- Clearer conceptual separation: repo = code, venv = runtime

**Trade-offs Considered:**
- ❌ Root-level venv: Standard but pollutes repo, easy to accidentally commit
- ❌ Platform-level venv: Non-standard, breaks tool expectations
- ✅ User-level venv: Clean, portable across clones, industry standard

### Wing IDE Configuration (v1.0.2-RC6)
**Automated Setup:** Bootstrap generates both .wpr and .wpu files

**.wpr (Project Settings):**
- Project root = repo root
- Recursive directory watching
- Exclusions: venv/, __pycache__/, .git/, .pytest_cache/, .venvs/
- **PYTHONPATH includes platform/content** for imports
- Debug initial directory = study/
- Can be committed (no user-specific data)

**.wpu (User Preferences):**
- Python interpreter: absolute path to `~/.venvs/paip/Scripts/python.exe` (Windows) or `~/.venvs/paip/bin/python` (Unix)
- NOT committed (user-specific)
- Wing auto-generates remaining GUI state

### Version Control
- Platform versions tagged (v1.0.0, v1.0.1, etc.)
- tools/ and content/ version together
- study/ never tracked in git
- .wpu excluded from git (user-specific)
- Install script copies itself to data-engineering-patterns repo

### Update Safety
- Installer detects old structures
- Automatic rollback to Downloads folder
- Complete platform/ folder replacement (not merge)
- study/ workspace always preserved
- User-level venv unaffected by updates
- Artifact cleanup for zip brace-expansion folders

## Installation Workflow

1. User downloads installer + zip
2. Confirmation prompt before proceeding
3. Git init with autocrlf=false (prevents CRLF warnings)
4. Old structure detection and rollback offer
5. Complete platform/ folder replacement
6. Zip extraction with artifact cleanup
7. study/ workspace creation if missing
8. Bootstrap runs automatically (logged to install.log)
9. Git operations manual (after QA certification)

## Bootstrap Process

`platform/tools/bootstrap.py` automates:

**Environment Setup:**
- GitHub home detection
- Patterns repo discovery
- PowerShell $PROFILE path detection (handles OneDrive)
- Shell profile configuration (PowerShell/Bash)
- Environment variables (GITHUB_HOME, PAIP_HOME, PATTERNS_REPO, PATTERNS_TOOLS)

**Python Environment:**
- Creates `~/.venvs/paip` virtual environment
- Installs requirements from `requirements.txt`
- Generates activation helper script

**Wing IDE:**
- Detects Wing installation
- Generates `.wpr` project file with PYTHONPATH for platform/content
- Generates `.wpu` user preferences with Python interpreter
- Configures debug initial directory to study/
- Configures source paths and exclusions

**Git:**
- Repository initialization if needed
- .gitignore configuration

## Git Configuration

### CRLF Handling
```batch
git config core.autocrlf false
```
Prevents line ending conversion warnings on Windows.

### Artifact Cleanup
Install script removes brace-expansion artifacts:
- `study/{practice_work,notes,mock_interviews}/`
- `platform/content/{src,docs,patterns,data}/`

## Version Control Copy

After installation, script offers to copy installer and platform zip to version control repository for centralized management:
- Default: `data-engineering-patterns/tools/paip/`
- Custom path option available
- Creates directory if missing

## Release Process

1. Develop changes in platform repo
2. Update version in README.md, install script, docs
3. Test installation via QA checklist
4. After QA certification, manually tag version: `git tag -a v1.0.X -m "Release description"`
5. Generate zip and installer
6. Push to KB repo
7. (Future) Create GitHub Release with artifacts

## Environment Variables

Bootstrap sets these automatically:
- **GITHUB_HOME**: Master GitHub folder location
- **PAIP_HOME**: This repository's path
- **PATTERNS_REPO**: data-engineering-patterns repository path
- **PATTERNS_TOOLS**: Patterns tools directory path

## Known Issues

### Import Configuration (RC8 Fix)
- Previous versions: imports failed because PYTHONPATH not configured
- RC8 fix: `.wpr` file includes `proj.pypath` with platform/content
- Bootstrap automatically configures this

### Zip Artifacts
Brace expansion in bash creates unwanted folders:
- Created: `{practice_work,notes,mock_interviews}/`
- Install script cleans these automatically

## Migration Path

### From v1.0.0 to v1.0.2-RC6
- venv location unchanged (user-level)
- Bootstrap auto-generates Wing configuration with PYTHONPATH
- PAIP_HOME environment variable added
- Install log now captures full installer output
- No manual steps required - run installer

### From v0.5.x to v1.0.2-RC6
- Download v1.0.1 installer + zip
- Run installer (auto-detects old structure)
- Old files moved to Downloads/paip-rollback-[date]
- study/ workspace preserved
- Bootstrap runs automatically

## Future Enhancements

- Docker environment setup (deferred until Wing complete)
- GitHub Releases for version downloads
- Automated testing of install script
- Active learning features (pattern drills, code validation)
- Interview simulator
