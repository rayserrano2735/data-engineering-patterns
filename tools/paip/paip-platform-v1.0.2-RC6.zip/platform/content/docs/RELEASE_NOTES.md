# Release Notes

## v1.0.2-RC6 (Current)

**Released:** October 6, 2025
**Status:** In QA Testing

### Major Changes

**Week 1 Content Complete:**
- PAIP_TEXTBOOK.md with complete Week 1 Python fundamentals (7 hours content)
- 20 exercises in week1_exercises.py matching textbook topics
- 35 flashcards in week1_flashcards.txt for spaced repetition
- INTERVIEW_MODE_WEEK1.md with AI interviewer guidelines

**Interview Mode Integration:**
- Added Interview Mode practice schedule to PAIP_TEXTBOOK.md Week 1 conclusion
- Added Interview Mode framework section to LEARNING_GUIDE.md
- Framework includes template for creating week-specific IM documents
- Students now understand when and how to use Interview Mode
- Course designers have structure for creating future week IM docs

**24-Pattern Library:**
- LEARNING_GUIDE.md contains complete 24-pattern library documentation
- Patterns categorized: Selection & Filtering, Aggregation, Time-Based, Ranking, Data Quality, Combination, Transformations, Performance
- Each pattern documented with when to use, implementation notes, and examples

**Documentation Improvements:**
- Renamed paip_textbook.md → PAIP_TEXTBOOK.md (uppercase for visibility)
- Created brand new QA_CHECKLIST.md with clean structure (deprecated old version)
- Updated ROADMAP.md with complete RC1-RC6 history
- Enhanced DEVELOPMENT_PROCESS.md with autonomous vs go-ahead decision framework

**Restored Documentation:**
- quick_reference.md - Quick syntax reference for interviews
- talking_points.md - Communication strategies for interviews

### Technical Changes

**Version Control:**
- Installer now copies 3 deliverables to version control: installer, platform zip, UNIT_TEST_CHECKLIST.md
- UNIT_TEST_CHECKLIST.md added as third deliverable for tracking test results

**Build Process:**
- Established unit test loop: dev tests before QA delivery
- 11 automated tests covering structure and content validation
- Tests verify versions, file presence, content integration, documentation completeness

### Files Added
- `/platform/content/docs/PAIP_TEXTBOOK.md` (renamed from lowercase)
- `/platform/content/docs/LEARNING_GUIDE.md` (with IM framework)
- `/platform/content/docs/INTERVIEW_MODE_WEEK1.md`
- `/platform/content/src/week1_exercises.py`
- `/platform/content/data/week1_flashcards.txt`
- `/platform/content/docs/QA_CHECKLIST.md` (new clean version)
- `/platform/content/docs/DEVELOPMENT_PROCESS.md`

### Files Modified
- All docs updated to v1.0.2-RC6
- ROADMAP.md - Added RC1-RC6 rejection history
- Installer - Added UNIT_TEST_CHECKLIST.md to VC copy

### Breaking Changes
- paip_textbook.md renamed to PAIP_TEXTBOOK.md (uppercase)
- Old QA_CHECKLIST.md deprecated, replaced with clean version

### Known Issues
- QA_CHECKLIST.md has one section header showing "RC6 (Rejected)" that should be "RC5 (Rejected)" - minor sed artifact, doesn't affect functionality

---

## v1.0.2-RC5 (Rejected)

**Released:** October 6, 2025
**Status:** Failed unit tests

### Why Rejected
- QA_CHECKLIST.md had duplicate RC5 sections from global sed replacement
- Historical RC labels incorrect (sed changed all RC3/RC4 to RC5)

### Changes Made
- Renamed paip_textbook.md → PAIP_TEXTBOOK.md
- Added Interview Mode schedule to PAIP_TEXTBOOK.md
- Added Interview Mode framework to LEARNING_GUIDE.md

---

## v1.0.2-RC4 (Rejected)

**Released:** October 6, 2025
**Status:** Failed QA

### Why Rejected
- Textbook filename should be uppercase
- Interview Mode not integrated into textbook
- Interview Mode framework missing from LEARNING_GUIDE.md

---

## v1.0.2-RC3 (Rejected)

**Released:** October 6, 2025
**Status:** Failed unit tests

### Why Rejected
- QA_CHECKLIST.md historical sections had wrong labels
- QA_CHECKLIST.md missing RC1 section

---

## v1.0.2-RC2 (Rejected)

**Status:** Failed QA

### Why Rejected
- Installer wrong version numbers
- QA_CHECKLIST.md historical sections overwritten

---

## v1.0.2-RC1 (Rejected)

**Status:** Failed QA

### Why Rejected
- Missing core content files

---

## v1.0.1 (Released)

**Released:** October 2025

Complete development environment with Wing IDE integration, desktop shortcuts, and git tracking.

### Key Features
- Automated bootstrap with PowerShell profile configuration
- Wing IDE integration with desktop shortcut
- Git tracking for study/ workspace
- PYTHONPATH configuration for imports
- Open-Wing PowerShell function

---

## v1.0.0 (Released)

Initial platform release with basic structure.
