#!/usr/bin/env python3
"""
Bootstrap Script - Automated Environment Setup
Handles all the manual steps automatically

This script:
1. Sets up PowerShell/Bash profile
2. Configures environment variables
3. Creates virtual environment
4. Installs requirements
5. Configures Wing IDE detection
"""

import os
import sys
import platform
import subprocess
import json
from pathlib import Path

class EnvironmentBootstrapper:
    """Automates all environment setup steps."""
    
    def __init__(self):
        self.system = platform.system()
        self.home = Path.home()
        self.patterns_repo = None
        self.github_home = None
        self.repo_path = None
        
    def detect_github_home(self):
        """Find or set the GitHub master folder."""
        # Common locations to check
        search_paths = [
            self.home / "GitHub",
            self.home / "Documents" / "GitHub",
            self.home / "Projects" / "GitHub",
            self.home / "Dropbox" / "Projects" / "GitHub",
            Path("C:/Users") / os.environ.get('USERNAME', '') / "GitHub",
            Path("C:/Users") / os.environ.get('USERNAME', '') / "Dropbox" / "Projects" / "GitHub",
        ]
        
        # Check existing environment variable
        if os.environ.get('GITHUB_HOME'):
            self.github_home = Path(os.environ['GITHUB_HOME'])
            print(f"✓ Using GITHUB_HOME from environment: {self.github_home}")
            return True
        
        # Auto-detect
        for path in search_paths:
            if path.exists():
                self.github_home = path
                print(f"✓ Found GitHub folder: {path}")
                return True
        
        # Ask user
        print("Could not auto-detect GitHub master folder.")
        user_path = input("Enter path to your GitHub folder (e.g., C:\\Users\\[name]\\GitHub): ").strip()
        if user_path and Path(user_path).exists():
            self.github_home = Path(user_path)
            return True
        
        return False
    
    def detect_patterns_repo(self):
        """Find the data-engineering-patterns repo."""
        if not self.github_home:
            return False
            
        # First check in GitHub home
        patterns_path = self.github_home / "data-engineering-patterns"
        if patterns_path.exists() and (patterns_path / "tools").exists():
            self.patterns_repo = patterns_path
            print(f"✓ Found patterns repo: {patterns_path}")
            return True
        
        # Fallback to other locations
        search_paths = [
            self.home / "GitHub" / "data-engineering-patterns",
            self.home / "Documents" / "GitHub" / "data-engineering-patterns",
            self.home / "Dropbox" / "Projects" / "GitHub" / "data-engineering-patterns",
        ]
        
        for path in search_paths:
            if path.exists() and (path / "tools").exists():
                self.patterns_repo = path
                print(f"✓ Found patterns repo: {path}")
                return True
        
        # Ask user
        print("Could not find data-engineering-patterns repo.")
        user_path = input("Enter full path to data-engineering-patterns (or press Enter to skip): ").strip()
        if user_path and Path(user_path).exists():
            self.patterns_repo = Path(user_path)
            return True
        
        return False
    
    def setup_powershell_profile(self):
        """Configure PowerShell profile on Windows."""
        if self.system != 'Windows':
            return
        
        print("\n🔧 Configuring PowerShell profile...")
        
        # PowerShell profile path
        ps_profile = self.home / "Documents" / "WindowsPowerShell" / "Microsoft.PowerShell_profile.ps1"
        
        # Create directory if needed
        ps_profile.parent.mkdir(parents=True, exist_ok=True)
        
        # Profile content
        profile_content = ps_profile.read_text() if ps_profile.exists() else ""
        
        # Check if already configured (more robust check)
        if '$env:PATTERNS_REPO' in profile_content and str(self.patterns_repo) in profile_content:
            print("  ✓ PowerShell profile already configured")
            return
        
        # Remove old entries if they exist (different path)
        lines = profile_content.splitlines()
        lines = [line for line in lines if '$env:PATTERNS_REPO' not in line and 
                 'PATTERNS_REPO\\tools' not in line and '$env:GITHUB_HOME' not in line]
        
        # Add our environment variables
        lines.extend([
            '',
            '# Python Interview Prep Environment (auto-generated)',
            f'$env:GITHUB_HOME = "{self.github_home}"',
            f'$env:PATTERNS_REPO = "{self.patterns_repo}"',
            f'$env:PATTERNS_TOOLS = "{self.patterns_repo}\\tools"',
            '$env:PATH = "$env:PATTERNS_TOOLS;$env:PATH"',
            ''
        ])
        
        ps_profile.write_text('\n'.join(lines))
        print(f"  ✓ Updated PowerShell profile: {ps_profile}")
        
        # Set execution policy (idempotent - won't fail if already set)
        try:
            subprocess.run([
                "powershell", "-Command",
                "Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force"
            ], check=True, capture_output=True)
            print("  ✓ PowerShell execution policy configured")
        except:
            pass  # Already set or no permissions
    
    def setup_bash_profile(self):
        """Configure bash profile on Mac/Linux."""
        if self.system == 'Windows':
            return
        
        print("\n🔧 Configuring shell profile...")
        
        # Determine which shell config to use
        shell = os.environ.get('SHELL', '/bin/bash')
        if 'zsh' in shell:
            profile_file = self.home / ".zshrc"
        else:
            profile_file = self.home / ".bashrc"
        
        # Profile content
        profile_content = profile_file.read_text() if profile_file.exists() else ""
        
        # Check if already configured
        if 'PATTERNS_REPO' in profile_content and str(self.patterns_repo) in profile_content:
            print("  ✓ Shell profile already configured")
            return
        
        # Remove old entries if they exist (different path)
        lines = profile_content.splitlines()
        lines = [line for line in lines if 'PATTERNS_REPO' not in line and 'GITHUB_HOME' not in line]
        
        # Add our environment variables
        lines.extend([
            '',
            '# Python Interview Prep Environment (auto-generated)',
            f'export GITHUB_HOME="{self.github_home}"',
            f'export PATTERNS_REPO="{self.patterns_repo}"',
            f'export PATTERNS_TOOLS="{self.patterns_repo}/tools"',
            'export PATH="$PATTERNS_TOOLS:$PATH"',
            ''
        ])
        
        profile_file.write_text('\n'.join(lines))
        print(f"  ✓ Updated shell profile: {profile_file}")
    
    def setup_virtual_environment(self):
        """Create and configure Python virtual environment."""
        print("\n🐍 Setting up Python virtual environment...")
        
        if not self.repo_path.exists():
            print("  ⚠ Repository doesn't exist yet. Run setup_python_interview_prep.py first.")
            return False
        
        venv_path = self.repo_path / "venv"
        
        if venv_path.exists():
            print(f"  ✓ Virtual environment already exists: {venv_path}")
        else:
            # Create venv
            subprocess.run([sys.executable, "-m", "venv", str(venv_path)], check=True)
            print(f"  ✓ Created virtual environment: {venv_path}")
        
        # Determine pip path
        if self.system == 'Windows':
            pip_path = venv_path / "Scripts" / "pip.exe"
            python_path = venv_path / "Scripts" / "python.exe"
        else:
            pip_path = venv_path / "bin" / "pip"
            python_path = venv_path / "bin" / "python"
        
        # Install requirements (check if needed first)
        requirements_file = self.repo_path / "requirements.txt"
        if requirements_file.exists():
            # Check if requirements are already satisfied
            print("  📦 Checking requirements...")
            check_result = subprocess.run(
                [str(pip_path), "show", "pandas", "numpy"], 
                capture_output=True, text=True
            )
            
            if check_result.returncode != 0:
                print("  📦 Installing requirements...")
                subprocess.run([str(pip_path), "install", "-r", str(requirements_file)], check=True)
                print("  ✓ Requirements installed")
            else:
                # Verify all requirements are met
                verify_result = subprocess.run(
                    [str(pip_path), "install", "--dry-run", "-r", str(requirements_file)],
                    capture_output=True, text=True
                )
                
                if "Would install" in verify_result.stdout:
                    print("  📦 Updating requirements...")
                    subprocess.run([str(pip_path), "install", "-r", str(requirements_file)], check=True)
                    print("  ✓ Requirements updated")
                else:
                    print("  ✓ Requirements already satisfied")
        
        # Create activation helper
        if self.system == 'Windows':
            activate_cmd = f"venv\\Scripts\\activate"
        else:
            activate_cmd = f"source venv/bin/activate"
        
        helper_script = self.repo_path / "activate_env.txt"
        helper_script.write_text(f"""
To activate the virtual environment, run:
  cd {self.repo_path}
  {activate_cmd}

Then you can run:
  python src/exercises.py
""")
        
        print(f"\n  📌 To activate virtual environment:")
        print(f"     cd {self.repo_path}")
        print(f"     {activate_cmd}")
        
        return True
    
    def download_wing_pro(self):
        """Offer to download Wing Pro if not found."""
        print("\n🦅 Checking for Wing Pro...")
        
        downloads = self.home / "Downloads"
        wing_files = list(downloads.glob("wing-pro*.deb"))
        
        if wing_files:
            print(f"  ✓ Found Wing Pro: {wing_files[0].name}")
        else:
            print("  ℹ Wing Pro not found in Downloads")
            print("  Download from: https://wingware.com/downloads/wing-pro")
            response = input("  Open download page in browser? (y/n): ").strip().lower()
            
            if response == 'y':
                import webbrowser
                webbrowser.open("https://wingware.com/downloads/wing-pro")
    
    def setup_git_config(self):
        """Configure git settings for the repo."""
        if not self.repo_path.exists():
            return
        
        print("\n🔧 Configuring Git...")
        
        os.chdir(self.repo_path)
        
        # Check if it's a git repo
        if not (self.repo_path / ".git").exists():
            response = input("  Initialize git repository? (y/n): ").strip().lower()
            if response == 'y':
                subprocess.run(["git", "init"], check=True)
                print("  ✓ Initialized git repository")
        else:
            print("  ✓ Git repository already initialized")
        
        # Set up .gitignore (idempotent - always overwrites with correct content)
        gitignore = self.repo_path / ".gitignore"
        gitignore_content = """# Python
__pycache__/
*.pyc
.pytest_cache/

# Virtual Environment
venv/
env/
.env

# IDE
.idea/
.vscode/
*.swp
.DS_Store

# Wing IDE
*.wpr
*.wpu

# User work
practice_work/*
!practice_work/.gitkeep
notes/*
!notes/.gitkeep
mock_interviews/*
!mock_interviews/.gitkeep

# Jupyter
.ipynb_checkpoints/
*.ipynb
"""
        
        # Only write if different
        if not gitignore.exists() or gitignore.read_text() != gitignore_content:
            gitignore.write_text(gitignore_content)
            print("  ✓ Updated .gitignore")
        else:
            print("  ✓ .gitignore already configured")
    
    def create_shortcuts(self):
        """Create helpful shortcuts/aliases."""
        print("\n🔗 Creating shortcuts...")
        
        # Create run script
        run_script = self.repo_path / "run.py"
        run_content = """#!/usr/bin/env python3
\"\"\"Quick launcher for common tasks.\"\"\"

import sys
import os

print("Python Analytics Interview Prep - Quick Launch")
print("=" * 50)
print("1. Run exercises")
print("2. Test patterns")
print("3. Open documentation")
print("4. Start Docker environment")

choice = input("\\nSelect option (1-4): ").strip()

if choice == '1':
    os.system(f"{sys.executable} src/exercises.py")
elif choice == '2':
    os.system(f"{sys.executable} src/patterns_and_gotchas.py")
elif choice == '3':
    os.system("start docs/README.md" if os.name == 'nt' else "open docs/README.md")
elif choice == '4':
    os.system("docker compose up")
else:
    print("Invalid choice")
"""
        
        # Only write if different or doesn't exist
        if not run_script.exists() or run_script.read_text() != run_content:
            run_script.write_text(run_content)
            run_script.chmod(0o755)
            print(f"  ✓ Created/updated run.py launcher")
        else:
            print(f"  ✓ run.py launcher already exists")
    
    def run_full_setup(self):
        """Run complete bootstrap process."""
        print("=" * 60)
        print("🚀 Python Interview Prep - Environment Bootstrapper")
        print("=" * 60)
        
        # Detect GitHub home folder
        if not self.detect_github_home():
            print("⚠ Could not determine GitHub folder. Please set manually.")
            return False
        
        # Set repo path based on GitHub home
        self.repo_path = self.github_home / "python-analytics-interview-prep"
        
        # Detect patterns repo
        if self.patterns_repo or self.detect_patterns_repo():
            # Configure shell profile
            if self.system == 'Windows':
                self.setup_powershell_profile()
            else:
                self.setup_bash_profile()
        
        # Setup Python environment
        self.setup_virtual_environment()
        
        # Git configuration
        self.setup_git_config()
        
        # Wing Pro check
        self.download_wing_pro()
        
        # Create shortcuts
        self.create_shortcuts()
        
        print("\n" + "=" * 60)
        print("✅ Bootstrap complete!")
        print("=" * 60)
        print("\nEnvironment variables set:")
        print(f"  GITHUB_HOME = {self.github_home}")
        print(f"  PATTERNS_REPO = {self.patterns_repo}")
        print(f"  PATTERNS_TOOLS = {self.patterns_repo}/tools")
        print("\nNext steps:")
        print("1. Restart your terminal (to load profile changes)")
        print("2. Navigate to: $GITHUB_HOME/python-analytics-interview-prep")
        print("3. Activate virtual environment")
        print("4. Run: python run.py")
        
        return True

def main():
    """Main entry point."""
    bootstrapper = EnvironmentBootstrapper()
    bootstrapper.run_full_setup()

if __name__ == "__main__":
    main()
