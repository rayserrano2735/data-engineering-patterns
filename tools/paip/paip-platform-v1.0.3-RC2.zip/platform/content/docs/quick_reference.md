# Quick Reference - Python Analytics Engineering Syntax

Rapid lookup during interviews. No explanations, just syntax.

## Lists

```python
lst = [1, 2, 3]
lst.append(4)                 # Add single item
lst.extend([5, 6])            # Add multiple items
lst.insert(0, 0)              # Insert at index
lst.remove(3)                 # Remove first occurrence
lst.pop()                     # Remove & return last
lst.pop(0)                    # Remove & return at index
lst.clear()                   # Remove all
lst.index(2)                  # Find index of value
lst.count(2)                  # Count occurrences
lst.sort()                    # Sort in place
lst.reverse()                 # Reverse in place
sorted(lst)                   # Return sorted copy
reversed(lst)                 # Return iterator
lst[:]                        # Shallow copy
lst[1:3]                      # Slice [start:stop]
lst[::2]                      # Slice with step
lst[::-1]                     # Reverse slice
```

## Dictionaries

```python
d = {'a': 1, 'b': 2}
d['c'] = 3                    # Add/update
d.get('a')                    # Get with None default
d.get('x', 0)                 # Get with custom default
d.pop('a')                    # Remove & return
d.popitem()                   # Remove & return arbitrary
d.clear()                     # Remove all
d.keys()                      # View of keys
d.values()                    # View of values
d.items()                     # View of (key, value)
d.update({'c': 3})           # Update from dict
d.setdefault('d', 4)         # Set if missing
'a' in d                      # Check key exists
dict.fromkeys(['a','b'], 0)  # Create with default value
```

## Sets

```python
s = {1, 2, 3}
s.add(4)                      # Add element
s.update([5, 6])              # Add multiple
s.remove(2)                   # Remove (error if missing)
s.discard(2)                  # Remove (no error)
s.pop()                       # Remove & return arbitrary
s.clear()                     # Remove all
s1 | s2                       # Union
s1 & s2                       # Intersection
s1 - s2                       # Difference
s1 ^ s2                       # Symmetric difference
s1.issubset(s2)              # s1 <= s2
s1.issuperset(s2)            # s1 >= s2
```

## Strings

```python
s = "  Hello World  "
s.strip()                     # Remove whitespace
s.lstrip()                    # Remove left whitespace
s.rstrip()                    # Remove right whitespace
s.lower()                     # Lowercase
s.upper()                     # Uppercase
s.capitalize()                # First letter uppercase
s.title()                     # Title Case
s.replace('o', 'a')          # Replace all
s.split()                     # Split on whitespace
s.split(',')                  # Split on delimiter
','.join(['a','b'])          # Join with delimiter
s.startswith('He')           # Check start
s.endswith('ld')             # Check end
s.find('o')                   # Find index (-1 if not found)
s.count('l')                  # Count occurrences
s.isdigit()                   # Check if all digits
s.isalpha()                   # Check if all letters
s.isalnum()                   # Check if alphanumeric
f"{var}"                      # f-string
"{} {}".format(a, b)         # Format method
```

## List Comprehensions

```python
[x for x in lst]              # Basic
[x for x in lst if x > 0]    # With filter
[x*2 for x in lst]            # With transformation
[x if x > 0 else 0 for x in lst]  # Conditional expression
[(x, y) for x in lst1 for y in lst2]  # Nested loops
[item for sublist in lst for item in sublist]  # Flatten
```

## Dictionary Comprehensions

```python
{k: v for k, v in items}      # Basic
{k: v for k, v in items if v > 0}  # With filter
{k: v*2 for k, v in items}    # Transform values
{v: k for k, v in items}      # Swap keys/values
```

## Lambda Functions

```python
lambda x: x * 2               # Basic
lambda x, y: x + y            # Multiple args
lambda x: x if x > 0 else 0   # Conditional
sorted(lst, key=lambda x: x[1])  # Sort by element
map(lambda x: x*2, lst)       # Apply to all
filter(lambda x: x > 0, lst)  # Filter elements
```

## Functions

```python
def func(a, b=1, *args, **kwargs):
    return result

func(1)                       # Positional
func(a=1, b=2)               # Keyword
func(1, 2, 3, 4)             # Extra positional → args
func(1, x=5, y=6)            # Extra keyword → kwargs
*lst                          # Unpack list to args
**dict                        # Unpack dict to kwargs
```

## File I/O

```python
# Text files
with open('file.txt', 'r') as f:
    content = f.read()        # Read all
    lines = f.readlines()     # Read lines to list
    line = f.readline()       # Read one line

with open('file.txt', 'w') as f:
    f.write('text')           # Write string
    f.writelines(lst)         # Write list of strings

# JSON
import json
data = json.load(f)           # Read from file
json.dump(data, f)            # Write to file
s = json.dumps(data)          # To string
data = json.loads(s)          # From string
```

## Error Handling

```python
try:
    risky_operation()
except ValueError as e:
    handle_value_error(e)
except (KeyError, IndexError):
    handle_key_or_index()
except Exception as e:
    handle_any_error(e)
else:
    runs_if_no_exception()
finally:
    always_runs()
```

## Pandas - DataFrames

```python
import pandas as pd
import numpy as np

# Creation
df = pd.DataFrame(data)
df = pd.read_csv('file.csv')
df = pd.read_excel('file.xlsx')
df = pd.read_json('file.json')

# Info
df.shape                      # (rows, cols)
df.dtypes                     # Column types
df.info()                     # Overview
df.describe()                 # Statistics
df.head(n)                    # First n rows
df.tail(n)                    # Last n rows
df.sample(n)                  # Random n rows

# Selection
df['col']                     # Select column
df[['col1', 'col2']]         # Select multiple columns
df.loc[row, col]             # Select by label
df.iloc[row, col]            # Select by position
df.loc[df['col'] > 5]        # Boolean indexing

# Modification
df['new'] = values           # Add column
df.drop(columns=['col'])     # Drop column
df.drop(index=[0,1])         # Drop rows
df.rename(columns={'old':'new'})  # Rename
df.sort_values('col')        # Sort by column
df.sort_values(['col1','col2'])  # Sort by multiple
df.reset_index(drop=True)    # Reset index
```

## Pandas - Operations

```python
# Missing Data
df.isnull()                   # Boolean mask
df.notnull()                  # Inverse mask
df.isnull().sum()            # Count nulls per column
df.dropna()                   # Drop rows with nulls
df.dropna(axis=1)            # Drop columns with nulls
df.fillna(0)                  # Fill with value
df.fillna(method='ffill')    # Forward fill
df.fillna(method='bfill')    # Backward fill
df.interpolate()              # Interpolate

# Duplicates
df.duplicated()               # Boolean mask
df.drop_duplicates()          # Remove duplicates
df.drop_duplicates(subset=['col'])  # By columns
df.drop_duplicates(keep='last')     # Keep last

# Apply Functions
df['col'].apply(func)         # Apply to column
df.apply(func, axis=1)        # Apply to rows
df.applymap(func)            # Apply to all elements
df['col'].map(dict)          # Map values
df['col'].replace({old: new}) # Replace values
```

## Pandas - GroupBy

```python
# Basic GroupBy
df.groupby('col')['val'].sum()
df.groupby('col')['val'].mean()
df.groupby('col')['val'].count()
df.groupby('col')['val'].min()
df.groupby('col')['val'].max()

# Multiple Aggregations
df.groupby('col').agg({'val1': 'sum', 'val2': 'mean'})
df.groupby('col')['val'].agg(['sum', 'mean', 'count'])

# Named Aggregations
df.groupby('col').agg(
    total=('val', 'sum'),
    average=('val', 'mean')
)

# Transform (keep original shape)
df.groupby('col')['val'].transform('mean')

# Filter groups
df.groupby('col').filter(lambda x: x['val'].sum() > 100)
```

## Pandas - Merge/Join

```python
# Merge
pd.merge(df1, df2, on='key')
pd.merge(df1, df2, on=['key1', 'key2'])
pd.merge(df1, df2, left_on='lkey', right_on='rkey')
pd.merge(df1, df2, how='left')   # left, right, inner, outer
pd.merge(df1, df2, indicator=True)  # Add _merge column

# Concat
pd.concat([df1, df2])         # Stack vertically
pd.concat([df1, df2], axis=1) # Side by side
pd.concat([df1, df2], ignore_index=True)

# Join (on index)
df1.join(df2)
```

## Pandas - Time Series

```python
# Parse Dates
pd.to_datetime(df['col'])
pd.to_datetime(df['col'], format='%Y-%m-%d')

# Date Components
df['date'].dt.year
df['date'].dt.month
df['date'].dt.day
df['date'].dt.dayofweek
df['date'].dt.day_name()
df['date'].dt.quarter

# Date Arithmetic
df['date'] + pd.Timedelta(days=1)
df['date'] - pd.Timedelta(hours=2)
(df['date1'] - df['date2']).dt.days

# Resampling
df.set_index('date').resample('D').sum()  # Daily
df.set_index('date').resample('M').mean() # Monthly

# Rolling Windows
df['col'].rolling(window=7).mean()
df['col'].rolling(window=7).sum()
df['col'].expanding().sum()   # Cumulative
```

## Pandas - Advanced

```python
# Pivot Tables
pd.pivot_table(df, values='val', index='row', columns='col')
pd.pivot_table(df, values='val', index='row', aggfunc='sum')

# Rank
df['rank'] = df['val'].rank()
df['rank'] = df['val'].rank(method='dense')
df['rank'] = df.groupby('group')['val'].rank()

# Shift/Lag
df['prev'] = df['val'].shift(1)
df['next'] = df['val'].shift(-1)
df['pct_change'] = df['val'].pct_change()

# Cumulative
df['cumsum'] = df['val'].cumsum()
df['cumsum'] = df.groupby('group')['val'].cumsum()

# Cut/Bins
pd.cut(df['val'], bins=3)
pd.cut(df['val'], bins=[0, 10, 20, 30])
pd.qcut(df['val'], q=4)      # Quartiles
```

## NumPy Essentials

```python
# Arrays
arr = np.array([1, 2, 3])
arr = np.zeros(5)
arr = np.ones((3, 3))
arr = np.arange(0, 10, 2)
arr = np.linspace(0, 10, 5)
arr = np.random.randn(10)

# Operations
np.sum(arr)
np.mean(arr)
np.std(arr)
np.min(arr)
np.max(arr)
np.argmin(arr)                # Index of min
np.argmax(arr)                # Index of max

# Conditions
np.where(arr > 0, arr, 0)     # If-else
np.select([cond1, cond2], [val1, val2], default)
```

## Common Patterns - Quick Copy

```python
# Top N by group
df.sort_values('val', ascending=False).groupby('group').head(n)
df.groupby('group').apply(lambda x: x.nlargest(n, 'val'))

# Percentage of total
df['pct'] = df['val'] / df['val'].sum() * 100
df['pct'] = df.groupby('group')['val'].transform(lambda x: x / x.sum())

# Remove outliers (3 std)
mean = df['val'].mean()
std = df['val'].std()
df = df[(df['val'] > mean - 3*std) & (df['val'] < mean + 3*std)]

# Memory optimization
for col in df.select_dtypes(['object']):
    df[col] = df[col].astype('category')
```

## Performance Tips

```python
# SLOW → FAST
# Iterrows → Vectorization
for i, row in df.iterrows():  # AVOID
df['new'] = df['old'] * 2     # PREFER

# Apply → Vectorization
df.apply(lambda x: x*2)        # SLOW
df * 2                         # FAST

# Python loop → NumPy
[x*2 for x in lst]            # SLOW
np.array(lst) * 2             # FAST

# Append in loop → Concat once
for data in chunks:
    df = df.append(data)       # SLOW
dfs = [process(chunk) for chunk in chunks]
df = pd.concat(dfs)           # FAST
```

## Method Chains

```python
# Clean pattern
result = (df
    .dropna()
    .groupby('category')
    .agg({'value': 'sum'})
    .sort_values('value', ascending=False)
    .head(10)
    .reset_index()
)
```

## Gotchas to Remember

```python
# Mutable defaults
def f(lst=[]):  # WRONG - shared across calls
def f(lst=None):  # RIGHT
    if lst is None: lst = []

# Modify while iterate
for item in lst:
    if condition:
        lst.remove(item)  # WRONG - skips elements

# Use instead:
lst = [x for x in lst if not condition]  # RIGHT

# SettingWithCopyWarning
df[df['col'] > 0]['col2'] = 1  # WRONG
df.loc[df['col'] > 0, 'col2'] = 1  # RIGHT

# Integer division
3 / 2    # 1.5 in Python 3
3 // 2   # 1 (floor division)
```

---

*Copy what you need. No time for explanations during interviews.*