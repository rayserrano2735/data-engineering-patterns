# PAIP Development Process
**Version:** 1.0.3-RC2

This document defines the complete development workflow for PAIP platform, including RC builds, unit testing, QA testing, and release cycles.

## Table of Contents

1. [Process Overview](#process-overview)
2. [Dev Responsibilities](#dev-responsibilities)
3. [QA Responsibilities](#qa-responsibilities)
4. [Key Principles](#key-principles)

---

## Process Overview

```
Dev builds RC → Unit tests → Delivers to QA → QA tests → Certification or Rejection
```

**Key stages:**
1. Dev logs changes in ROADMAP
2. Dev builds RC and runs unit tests
3. Dev delivers to QA with unit test results
4. QA tests against QA_CHECKLIST
5. QA certifies or rejects
6. If rejected: Dev logs reasons, builds next RC
7. If certified: Tag release, start next version

---

## Dev Responsibilities

### Autonomous vs Go-Ahead Decisions

**Autonomous:**
- Technical implementation
- Code structure
- Unit test design
- Documentation
- Bug fixes from QA
- RC increments

**Requires go-ahead:**
- New features not in ROADMAP
- Process changes
- Breaking changes
- Major architecture decisions
- Scope changes

**Principle:** Optimize for velocity within scope. When uncertain, do it and note in ROADMAP.

### Building an RC

1. Log changes in ROADMAP
2. Apply changes
3. Update doc versions
4. Build deliverables (platform zip, installer)
5. Run unit tests
6. Copy unit test checklist to outputs
7. Deliver to QA

### Unit Testing

Run automated tests before QA delivery. Document results in UNIT_TEST_CHECKLIST.md.

**Standard tests:**
- Installer version consistency
- Platform zip contents
- Doc version consistency
- QA_CHECKLIST structure
- ROADMAP structure
- Python syntax check
- File counts
- Content validation

Only deliver to QA when all tests pass.

### After QA Reports Findings

1. Review findings
2. Log rejection reasons in ROADMAP
3. Log fixes in new RC section
4. Apply fixes
5. Increment RC number
6. Run unit tests
7. Deliver new RC

### After QA Certification

1. Move certified RC to "Completed Versions" in ROADMAP
2. QA tags release (e.g., v1.0.3)
3. Start new version (e.g., v1.0.3-RC2)

---

## QA Responsibilities

### Testing an RC

Test against QA_CHECKLIST.md using:
- Windows environment
- Fresh installation
- Complete checklist walkthrough

### Reporting Findings

Document:
- Specific failures
- Reproduction steps
- Severity

### Certification Decision

**Certify:** All critical items pass
**Reject:** Any critical item fails

---

## Key Principles

1. **No Piecemeal Changes:** New RC for any change after QA delivery
2. **Explicit QA Decision:** Certify or reject explicitly
3. **Complete Logging:** All rejections logged with reasons
4. **Unit Tests Gate QA:** Only deliver passing unit tests
5. **Historical Preservation:** Complete RC history in ROADMAP/QA_CHECKLIST

