# Release Notes

## v1.0.3-RC2 (Current)

**Released:** October 6, 2025
**Status:** In QA Testing

### Major Changes

**Test-Driven Development Infrastructure:**
- Converted week1_exercises.py to TDD structure:
  - week1_exercises.py: 20 exercise stubs (students write code)
  - test_week1_exercises.py: Test harness with expected outputs  
  - week1_solutions.py: Reference solutions for self-checking
- Teaches TDD methodology from Week 1
- Students validate solutions programmatically

**Testing Patterns Added:**
- 5 new patterns (25-29) for testing and validation
- Edge case testing, assertions, test data generation
- Parametrized testing, pandas operation testing
- Total pattern library: 29 patterns

**Enhanced Learning Materials:**
- Python Prerequisites section in LEARNING_GUIDE.md (extracted from 29 patterns)
- Textbook "exercises" renamed to "examples" (solutions shown for learning)
- Exercise references added to textbook at end of each day
- Flashcards expanded with 15 practical exercise cards (total: 50)

**Interview Mode Enhancements:**
- Extended thinking mode integration for better scenario planning
- Voice mode (bidirectional) documentation for realistic interview simulation
- Students can practice verbal communication, not just coding

**Documentation Updates:**
- DEVELOPMENT_PROCESS.md recreated (lost during RC5 restoration)
- PLATFORM_ARCHITECTURE.md updated with Week 1 content structure
- ROADMAP reorganized with Product Backlog section

### Files Added
- `/platform/content/src/test_week1_exercises.py` - Test harness
- `/platform/content/src/week1_solutions.py` - Reference solutions
- `/platform/content/docs/DEVELOPMENT_PROCESS.md` - Process documentation

### Files Modified
- week1_exercises.py - Converted to stubs only
- week1_flashcards.txt - Added 15 practical exercise cards
- LEARNING_GUIDE.md - Added Python Prerequisites, 5 testing patterns, IM enhancements
- PAIP_TEXTBOOK.md - Renamed exercises→examples, added exercise references
- PLATFORM_ARCHITECTURE.md - Updated for Week 1 structure
- ROADMAP.md - Added Product Backlog section

### Breaking Changes
- week1_exercises.py no longer contains solutions (moved to week1_solutions.py)
- Students must now run test_week1_exercises.py to validate

---

## v1.0.2 (Released)

**Released:** October 6, 2025

Week 1 foundation content with complete textbook, 24-pattern library, and Interview Mode integration.

**Key Features:**
- PAIP_TEXTBOOK.md with Week 1 Python fundamentals
- LEARNING_GUIDE.md with 24-pattern library
- 20 exercises, 35 flashcards
- Interview Mode framework and schedule
- Clean QA_CHECKLIST.md structure

---

## v1.0.1 (Released)

**Released:** October 2025

Complete development environment with Wing IDE integration, desktop shortcuts, and git tracking.

