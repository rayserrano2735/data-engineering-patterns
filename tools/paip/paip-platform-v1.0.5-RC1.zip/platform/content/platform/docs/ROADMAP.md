# PAIP Platform Roadmap
**Version:** 1.0.5-RC1

## Current Release: v1.0.5
Content quality improvements, QA automation, and textbook enhancements.

---

## In Progress

### v1.0.5-RC1 - Content Quality & QA Automation
**Target:** Current release candidate
**Status:** Building

**User Stories:**

**Story 1: Wing IDE Window Size Preference** (Small)
- As a user, I want Wing IDE to open at a default size instead of maximized so I don't have to resize it every time

**Acceptance Criteria:**
- Add window geometry settings to _generate_wpu_file() in bootstrap.py
- Configure default window size (e.g., 1400x900 or 80% screen size)
- Configure default position (centered or user-specified)
- Ensure settings apply on first Wing launch after installation

**Story 2: Clarify RC-to-Version Migration in Dev Process** (Small)
- As a developer, I want clear guidance on what happens to RC5+ items when an RC is certified so I know where to log new work

**Acceptance Criteria:**
- Update DEVELOPMENT_PROCESS.md "After QA Certification" section
- Document that items logged for RC5+ during RC4 testing migrate to next version's RC1 upon certification
- Document that items stay as RC5 if RC4 is rejected
- Add example workflow showing certification path vs rejection path

**Story 3: Complete Content Dependency Audit - Platform Wide** (Large)
- As a student, I want ALL concepts introduced before use throughout the entire platform so I'm never confused by undefined syntax or unexplained concepts

**Context:** This story was marked complete in RC1 and RC3 but only partial fixes were applied (dict.fromkeys). The comprehensive platform-wide audit has never been completed. This is the third time this issue has been incorrectly closed.

**Guiding Principle:** No concept, method, syntax pattern, or language feature may be used in any example, exercise, or explanation before it has been explicitly introduced and explained to the student.

**Acceptance Criteria:**
- Systematic audit: Inventory ALL methods, functions, syntax patterns, and concepts used across entire platform
- For each item: Document WHERE first used and WHERE (if at all) first explained
- Create violations checklist: Items used before explanation
- Fix ALL violations platform-wide (not just dict.fromkeys and Example 1.1)
- Verify no forward references exist in any student-facing content
- Add automated test that fails if new content dependency violations are introduced
- Document the audit methodology so future content additions can be validated

**Story 4: Clarify Lists vs Dicts as DataFrame Rows** (Small)
- As a student, I want a clear mental model of how lists and dicts map to DataFrames so I understand data structure conversion

**Acceptance Criteria:**
- Fix textbook explanation that says "both lists and dictionaries can be converted into Pandas rows"
- Clarify: List of dicts → table (each dict = row), List of lists → table (each list = row)
- Use mental model: List = Table, Dictionary = Row
- Map to SQL concepts: list of dicts → SELECT result set, dict → record/row, dict keys → column names
- Update in PAIP_TEXTBOOK.md Day 1-2 section where interview connection is mentioned

**Story 5: Add Intuition Entries for Core Concepts** (Small)
- As a student, I want intuition entries for confusing deduplication and data structure patterns so I understand the design rationale

**Acceptance Criteria:**
- Add INTUITIONS.md entry: "Deduplication: dict.fromkeys() vs set()" covering order preservation difference
- Add INTUITIONS.md entry: "Lists and Dicts as DataFrame Structures" covering List = Table, Dict = Row mental model
- Both entries follow template format with SQL mappings and interview strategy
- Explain when to use each approach and why it matters in analytics context

**Story 6: Add Iteration Patterns to Quick Reference** (Small)
- As a student, I want iteration syntax in the quick reference so I can quickly recall loop patterns during practice

**Acceptance Criteria:**
- Add iteration section to QUICK_REFERENCE.md
- Include: for loops, while loops, enumerate(), zip(), range()
- Include: break, continue, else clauses
- Include common patterns: iterating dicts (.items(), .keys(), .values())
- Keep concise quick-reference format (syntax only, minimal explanation)

**Story 7: Add Dict/Set Edge Cases to Textbook** (Small)
- As a student, I want to know edge cases like `{}` creating a dict not a set so I can handle interview gotcha questions

**Acceptance Criteria:**
- Add to PAIP_TEXTBOOK.md Day 1-2 Sets section: `{}` creates empty dict, use `set()` for empty set
- Explain why: dict came first in Python, gets precedence for `{}`
- Add to common interview questions/gotchas
- Include example showing the difference

**Story 8: Clarify Set Difference vs Symmetric Difference** (Small)
- As a student, I want clear explanation of set difference (-) vs symmetric difference (^) so I understand when to use each

**Acceptance Criteria:**
- Expand PAIP_TEXTBOOK.md Day 1-2 Sets section with clear examples
- Difference (a - b): Elements in a but NOT in b
- Symmetric difference (a ^ b): Elements in EITHER a or b but NOT BOTH (XOR logic)
- Include visual examples showing the difference
- Add use case for each operation
- Add INTUITIONS.md entry: "Set Difference vs Symmetric Difference" with SQL analogy and when to use each

**Story 9: Evaluate Better Approach for INTUITIONS.md Management** (Small)
- As platform developers, we need to determine the right location and update strategy for INTUITIONS.md

**Acceptance Criteria:**
- Evaluate current placement in platform/content/student/docs/
- Determine if location/update mechanism needs to change
- Document decision rationale in ROADMAP or DEVELOPMENT_PROCESS

**Story 10: Rename "Practice Problems" to "Practice Examples"** (Small)
- As a student, I want accurate heading that distinguishes examples from exercises

**Context:** This is the second time this has been raised and not fixed.

**Acceptance Criteria:**
- Find all instances of "Practice Problems" heading in PAIP_TEXTBOOK.md
- Rename to "Practice Examples" 
- Ensure consistency across entire textbook

**Story 11: Textbook Coordinates All Learning Activities** (Medium)
- As a student, I want the textbook to direct me to exercises, flashcards, and Interview Mode after each day's content so I have a clear study path

**Acceptance Criteria:**
- After each day's content section in PAIP_TEXTBOOK.md, add learning activity block
- Direct to specific exercises (e.g., "Complete Exercises 1.1-1.5 in week1_exercises.py")
- Direct to relevant flashcards (e.g., "Review day1-2_flashcards.txt")
- Direct to Interview Mode practice (e.g., "Practice with INTERVIEW_MODE_WEEK1.md focusing on dictionaries and lists")
- Make textbook the central coordinator for complete learning flow
- Apply to all 7 days in Week 1

**Story 12: QA Automation Framework** (Large)
- As QA, I want automated tests that validate content dependencies, version consistency, and file structure so manual testing is faster

**Acceptance Criteria:**
- Create platform/tools/qa_automation.py script
- Automated tests: version string consistency across all docs, installer references correct zip, content dependency violations (from Story 3 audit), file structure validation, unit test checklist presence
- Script returns exit code 0 (pass) or 1 (fail) for CI integration
- Generate test report with pass/fail details
- Add to DEVELOPMENT_PROCESS.md as pre-QA delivery step
- Update UNIT_TEST_CHECKLIST to reference automated tests

**QA Status:** Pending build

**Story 9 Resolution:** INTUITIONS.md remains in platform/content/student/docs/ as platform-maintained content. It updates with each platform release via normal zip extraction. Students can reference it but platform owns canonical content. Personal student notes go in study/notes/.

---

## Rejected RCs

### v1.0.4-RC3 - RC2 Rejection Fixes (Rejected)
**Rejected:** October 7, 2025
**Reason:** Student folder structure missing from installation (files moved in workspace but not included in zip correctly; flawed unit test checked path string instead of actual files)

**Completed Work in RC3:**
- Documentation reorganization: Created platform/content/student/ and platform/content/platform/ folder structures
- Added TOCs to PAIP_TEXTBOOK, LEARNING_GUIDE, INTERVIEW_MODE
- Renamed quick_reference.md → QUICK_REFERENCE.md
- Renamed talking_points.md → TALKING_POINTS.md
- Split 74 flashcards into day1-2 through day7 files (daily learning packages)
- Created daily exercise wrappers (day1-2_exercises.py through day7_exercises.py)
- Fixed dict.fromkeys content dependency (added to Essential Built-in Functions section)
- Detailed comprehension evaluation order in PAIP_TEXTBOOK.md (lines 360-395)

### v1.0.4-RC2 - Airflow Integration & RC1 Fixes (Rejected)
**Rejected:** October 7, 2025
**Reason:** Installer referenced wrong zip filename (v1.0.4-RC3.zip instead of v1.0.4-RC3.zip)

**Completed Work in RC1:**
- Created INTUITIONS.md template with list comprehension entry
- Added comprehension deep-dive to textbook
- Added Essential Built-in Functions section before examples
- Clarified "ordered" vs "sorted" in lists section
- Added result examples to quick_reference.md
- Expanded flashcards from 50 to 74 (+24 method cards)
- Documented Wing IDE Git integration
- Added token budget tracking to DEVELOPMENT_PROCESS.md
- Added backlog refinement section to DEVELOPMENT_PROCESS.md

---

## Completed Versions

### v1.0.4 (Released - October 7, 2025)

Testing infrastructure and content refinements with student/platform folder reorganization.

**Delivered in RC4:**
- Student folder structure properly packaged (platform/content/student/ and platform/content/platform/)
- Documentation reorganization with TOCs
- Daily learning packages (flashcards and exercises split by day)
- Fixed dict.fromkeys content dependency
- Renamed quick_reference.md → QUICK_REFERENCE.md, talking_points.md → TALKING_POINTS.md
- Detailed comprehension evaluation order explanation
- Versioned unit test checklist (UNIT_TEST_CHECKLIST-vX.X.X-RCX.md)
- RC version shown in install.log

**Key Features:**
- TDD structure: week1_exercises.py (stubs), test_week1_exercises.py (harness), week1_solutions.py (solutions)
- 29 patterns (24 data manipulation + 5 testing/validation)
- Python Prerequisites section extracted from patterns
- 74 flashcards (expanded from 50)
- Extended thinking + voice mode for Interview Mode
- Exercise references in textbook
- DEVELOPMENT_PROCESS.md recreated
- PLATFORM_ARCHITECTURE.md updated

### v1.0.2 (Released)

Week 1 foundation content with textbook and pattern library.

**Key Features:**
- PAIP_TEXTBOOK.md with Week 1 Python fundamentals
- LEARNING_GUIDE.md with 24-pattern library
- 20 exercises, 35 flashcards
- Interview Mode framework and schedule

### v1.0.1 (Released)

Development environment with Wing IDE integration.

---

## Product Backlog (Unscheduled)

Items logged for future consideration, not yet assigned to a release version.

### Interview Mode Enhancements
- Pattern contribution workflow: "Submit New Pattern" form for interviewers/users
- Potential lead generation: interviewers who contribute become prospects

### Analytics & Reporting
- Interview Mode Analytics: Session data capture, CSV/JSON export, Snowflake schema, Tableau dashboards

### Content Gaps
- Multi-pattern capstone project (exercises currently isolated)
- Systematic debugging drill framework (current debug exercises ad-hoc)

### Content Expansion
- Weeks 2-3 content (DataFrame basics + aggregation patterns)
- Weeks 4-5 content (Ranking/windows + advanced patterns)
- Weeks 6-7 content (Integration + meta-patterns)

---

## Future Releases

### v1.0.4 (In Progress)
Content order and learning framework improvements.

### v1.0.5 (Planned)
Week 2 content (DataFrame basics + first pattern versions).

