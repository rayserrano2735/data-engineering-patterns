# QA Checklist

This document maintains testing criteria for each PAIP release. Each version includes both regression tests (features from previous versions) and new feature validation.

---

## v1.0.2-RC3 - Week 1 Foundation Content

### Installation
- [ ] Run installer (silent mode)
- [ ] Check install.log for full output
- [ ] Verify git repo initialized

### Bootstrap Execution  
- [ ] Verify bootstrap ran successfully
- [ ] **CRITICAL:** Check install.log shows "Updated PowerShell profile" (NOT "already configured")
- [ ] Check venv exists at `~/.venvs/paip`

### PowerShell Profile Verification (THE CRITICAL TEST)
- [ ] **CRITICAL:** Open PowerShell profile: `notepad $PROFILE`
- [ ] Verify it contains ALL these lines:
  - [ ] `# Python Interview Prep Environment (auto-generated)`
  - [ ] `$env:GITHUB_HOME = "..."`
  - [ ] `$env:PAIP_HOME = "..."`
  - [ ] `$env:PYTHONPATH = "...\platform\content"`
  - [ ] `$env:PATTERNS_REPO = "..."`
  - [ ] `$env:PATTERNS_TOOLS = "..."`
  - [ ] `$env:PATH = "..."`
- [ ] Verify NO duplicate PAIP entries in profile

### Environment Variables (After Terminal Restart)
- [ ] **Restart PowerShell completely**
- [ ] Run: `echo $env:PYTHONPATH`
- [ ] **CRITICAL:** Should show path ending in `\platform\content`
- [ ] Verify other vars: GITHUB_HOME, PAIP_HOME, PATTERNS_REPO, PATTERNS_TOOLS

### Wing IDE Configuration
- [ ] Verify .wpu file has ONLY `proj.pyexec` (no proj.env-vars)
- [ ] Verify .wpr file contains proj.pypath line
- [ ] **CRITICAL:** Check desktop for "PAIP - Wing IDE" shortcut
- [ ] Double-click desktop shortcut - Wing should launch with project
- [ ] Alternative: Open new PowerShell, run `Open-Wing` command
- [ ] Wing should start Python shell successfully
- [ ] Test in Python shell: `import sys; print(sys.path)`
- [ ] Verify platform/content path in sys.path

### Import Testing
- [ ] Close and reopen Wing IDE
- [ ] Create test in study/practice_work/: `from src.patterns_and_gotchas import CorePatterns`
- [ ] **CRITICAL:** Run - should execute without ModuleNotFoundError
- [ ] Test: `from src.exercises import exercise_1_1`

### Week 1 Content Verification
- [ ] Verify paip_textbook.md exists in platform/content/docs/
- [ ] Verify Week 1 section is complete (7 hours content)
- [ ] Verify week1_exercises.py exists in platform/content/src/
- [ ] Run: `python platform/content/src/week1_exercises.py` - all exercises should pass
- [ ] Verify week1_flashcards.txt exists in platform/content/data/
- [ ] Verify INTERVIEW_MODE_WEEK1.md exists in platform/content/docs/
- [ ] Verify LEARNING_GUIDE.md contains 24-pattern library documentation
- [ ] Verify quick_reference.md exists in platform/content/docs/
- [ ] Verify talking_points.md exists in platform/content/docs/
- [ ] Verify course_with_schedule.md exists (legacy, unchanged)

### Git Configuration
- [ ] Create test file in study/practice_work/
- [ ] Run `git status` - file should appear
- [ ] Verify .wpr tracked, .wpu ignored

### QA Certification
**After ALL checklist items pass:**
- [ ] Git operations:
  ```
  git add platform/ .gitignore README.md requirements.txt activate_env.txt study/
  git add python-analytics-interview-prep.wpr
  git commit -m "Platform v1.0.2-RC3"
  git tag -a v1.0.2 -m "Release v1.0.2"
  ```

---

## v1.0.2-RC3 - Week 1 Foundation Content (Rejected)

**Why Rejected:**
- Installer had wrong version numbers (v1.0.1-RC24 instead of v1.0.2-RC3)
- QA_CHECKLIST.md historical sections overwritten instead of preserved

### Installation
- [ ] Run installer (silent mode)
- [ ] Check install.log for full output
- [ ] Verify git repo initialized

### Bootstrap Execution  
- [ ] Verify bootstrap ran successfully
- [ ] **CRITICAL:** Check install.log shows "Updated PowerShell profile" (NOT "already configured")
- [ ] Check venv exists at `~/.venvs/paip`

### PowerShell Profile Verification (THE CRITICAL TEST)
- [ ] **CRITICAL:** Open PowerShell profile: `notepad $PROFILE`
- [ ] Verify it contains ALL these lines:
  - [ ] `# Python Interview Prep Environment (auto-generated)`
  - [ ] `$env:GITHUB_HOME = "..."`
  - [ ] `$env:PAIP_HOME = "..."`
  - [ ] `$env:PYTHONPATH = "...\platform\content"`
  - [ ] `$env:PATTERNS_REPO = "..."`
  - [ ] `$env:PATTERNS_TOOLS = "..."`
  - [ ] `$env:PATH = "..."`
- [ ] Verify NO duplicate PAIP entries in profile

### Environment Variables (After Terminal Restart)
- [ ] **Restart PowerShell completely**
- [ ] Run: `echo $env:PYTHONPATH`
- [ ] **CRITICAL:** Should show path ending in `\platform\content`
- [ ] Verify other vars: GITHUB_HOME, PAIP_HOME, PATTERNS_REPO, PATTERNS_TOOLS

### Wing IDE Configuration
- [ ] Verify .wpu file has ONLY `proj.pyexec` (no proj.env-vars)
- [ ] Verify .wpr file contains proj.pypath line
- [ ] **CRITICAL:** Check desktop for "PAIP - Wing IDE" shortcut
- [ ] Double-click desktop shortcut - Wing should launch with project
- [ ] Alternative: Open new PowerShell, run `Open-Wing` command
- [ ] Wing should start Python shell successfully
- [ ] Test in Python shell: `import sys; print(sys.path)`
- [ ] Verify platform/content path in sys.path

### Import Testing
- [ ] Close and reopen Wing IDE
- [ ] Create test in study/practice_work/: `from src.patterns_and_gotchas import CorePatterns`
- [ ] **CRITICAL:** Run - should execute without ModuleNotFoundError
- [ ] Test: `from src.exercises import exercise_1_1`

### Git Configuration
- [ ] Create test file in study/practice_work/
- [ ] Run `git status` - file should appear
- [ ] Verify .wpr tracked, .wpu ignored

### QA Certification
**After ALL checklist items pass:**
- [ ] Git operations:
  ```
  git add platform/ .gitignore README.md requirements.txt activate_env.txt study/
  git add python-analytics-interview-prep.wpr
  git commit -m "Platform v1.0.2-RC3"
  git tag -a v1.0.1 -m "Release v1.0.1"
  ```

---

## v1.0.2-RC3 - Development Environment Setup (Rejected)

### Installation
- [ ] Run installer (silent mode) - completes without prompts
- [ ] Check install.log for full output
- [ ] Verify git repo initialized

### Bootstrap Execution
- [ ] Verify bootstrap ran successfully
- [ ] Check venv exists at `~/.venvs/paip`
- [ ] **CRITICAL:** Open PowerShell profile and verify PYTHONPATH line present:
  - [ ] `$env:PYTHONPATH = "path/to/platform/content"`
- [ ] Check environment variables:
  - [ ] GITHUB_HOME
  - [ ] PAIP_HOME
  - [ ] PYTHONPATH (new in RC11)
  - [ ] PATTERNS_REPO
  - [ ] PATTERNS_TOOLS

### Wing IDE Configuration (NEW - RC11 Critical Fix)
- [ ] **CRITICAL:** Open .wpu file and verify it contains:
  - [ ] `proj.env-vars = {None: {'PYTHONPATH': 'path/to/platform/content'}}`
- [ ] Verify .wpr file contains proj.pypath line
- [ ] Verify .wpu file contains proj.pyexec line

### Import Testing (THE CRITICAL TEST)
- [ ] **Restart terminal** to load new environment variables
- [ ] Open Wing IDE (close and reopen if already open)
- [ ] Create test script in study/practice_work/: `from src.patterns_and_gotchas import CorePatterns`
- [ ] **CRITICAL:** Run script - should execute without ModuleNotFoundError
- [ ] Test: `from src.exercises import exercise_1_1`
- [ ] Verify debugging works

### Git Configuration
- [ ] **CRITICAL:** Create test file in study/practice_work/test.py
- [ ] Run `git status` - test.py should appear as untracked
- [ ] Verify .wpr file is NOT in .gitignore (should be tracked)
- [ ] Verify .wpu file IS in .gitignore (should not be tracked)
- [ ] Add and commit test file - should work

### QA Certification
**After ALL checklist items pass:**
- [ ] Git operations:
  ```
  git add platform/ .gitignore README.md requirements.txt activate_env.txt study/
  git add python-analytics-interview-prep.wpr
  git commit -m "Platform v1.0.2-RC3"
  git tag -a v1.0.1 -m "Release v1.0.1"
  ```
- [ ] Verify tag created
- [ ] Push to remote

---

## v1.0.2-RC3 - Development Environment Setup (Rejected)

### Installation
- [ ] Run installer (silent mode) - completes without prompts
- [ ] Check install.log captures full output
- [ ] Verify git repo initialized
- [ ] Test /interactive flag if needed

### Bootstrap Execution
- [ ] Verify bootstrap ran successfully (check install.log)
- [ ] Check venv exists at `~/.venvs/paip`
- [ ] Verify environment variables set (GITHUB_HOME, PAIP_HOME, PATTERNS_REPO, PATTERNS_TOOLS)
- [ ] Confirm .wpr generated with proj.pypath line
- [ ] Confirm .wpu generated with Python interpreter path

### Python Package Structure (NEW - RC10 Critical Fix)
- [ ] **CRITICAL:** Verify platform/content/__init__.py exists
- [ ] **CRITICAL:** Verify platform/content/src/__init__.py exists
- [ ] **CRITICAL:** Verify platform/content/patterns/__init__.py exists

### Wing IDE Integration
- [ ] Open .wpr in Wing Pro
- [ ] Create test script: `from src.patterns_and_gotchas import CorePatterns`
- [ ] **CRITICAL:** Verify import works without ModuleNotFoundError
- [ ] Run script with F5 - executes successfully
- [ ] Test: `from src.exercises import exercise_1_1`
- [ ] Verify debugging works

### Git Configuration (NEW - RC10 Critical Fix)
- [ ] **CRITICAL:** Create test file in study/practice_work/
- [ ] Run `git status` - file should appear as untracked
- [ ] Student work is version controlled (not ignored)
- [ ] Verify .gitignore does NOT exclude study/ content

### Documentation
- [ ] All docs have RC10 version headers
- [ ] ROADMAP shows RC10 status and RC9 rejection reason
- [ ] RELEASE_NOTES has RC10 entry

### QA Certification
**After ALL checklist items pass:**
- [ ] Git operations:
  ```
  git add platform/ .gitignore README.md requirements.txt activate_env.txt study/
  git commit -m "Platform v1.0.2-RC3"
  git tag -a v1.0.1 -m "Release v1.0.1"
  ```
- [ ] Verify tag created
- [ ] Push to remote

---

## v1.0.2-RC3 - Development Environment Setup (Rejected)

### Installation
- [ ] Run installer (silent mode) - no prompts should appear
- [ ] Verify installer completes without user input
- [ ] Check install.log captures full output
- [ ] Verify git repo initialized
- [ ] Confirm .gitignore updated with Wing entries
- [ ] Test /interactive flag - prompts should appear
- [ ] Verify error messages display on screen (test by removing git from PATH temporarily)

### Bootstrap Execution
- [ ] Verify via install.log that bootstrap ran successfully
- [ ] Check venv exists at `~/.venvs/paip`
- [ ] Verify packages installed: `pip list` shows pandas, numpy, openpyxl
- [ ] Check environment variables via terminal:
  - [ ] GITHUB_HOME shows correct path
  - [ ] PAIP_HOME shows repo path
  - [ ] PATTERNS_REPO shows correct path
  - [ ] PATTERNS_TOOLS shows correct path
- [ ] Confirm .wpr file generated
- [ ] **CRITICAL:** Open .wpr in text editor and verify it contains:
  - [ ] `proj.pypath = {None: ('path/to/platform/content',)}`
  - [ ] `debug.project-home = 'path/to/study'`
- [ ] Confirm .wpu file generated with Python interpreter path

### Wing IDE Integration
- [ ] Open .wpr file in Wing Pro
- [ ] Verify Python interpreter auto-detected (venv path in status bar)
- [ ] Create test script in study/practice_work/ with: `from src.patterns_and_gotchas import CorePatterns`
- [ ] **CRITICAL:** Verify import works without errors
- [ ] Run script with F5 - should execute successfully
- [ ] Test: `from src.exercises import exercise_1_1`
- [ ] Verify debugging breakpoints work
- [ ] Check project tree excludes venv/, __pycache__, .git/, .venvs/

### Documentation Accuracy
- [ ] All docs have version headers (v1.0.2-RC3)
- [ ] README.md references RC9
- [ ] ROADMAP.md shows RC9 status and RC8 rejection reason
- [ ] RELEASE_NOTES.md has RC9 entry explaining fixes
- [ ] Install.log "Next steps" clarifies venv activation for command line only

### Content Integrity
- [ ] All exercises present in platform/content/src/exercises.py
- [ ] All patterns present in platform/content/src/patterns_and_gotchas.py
- [ ] Flashcards file exists in platform/content/data/
- [ ] All doc files present in platform/content/docs/
- [ ] Study folder structure intact

### Critical Fix Verification
- [ ] **IMPORT FIX:** Verify .wpr contains proj.pypath line (check file directly)
- [ ] **IMPORT FIX:** Test import in Wing IDE actually works
- [ ] **INSTALLER FIX:** Silent mode works (no prompts)
- [ ] **INSTALLER FIX:** Errors display on screen
- [ ] **INSTALLER FIX:** /interactive flag shows prompts

### QA Certification
**After ALL checklist items pass:**
- [ ] Manually run git operations:
  ```
  git add platform/ .gitignore README.md requirements.txt activate_env.txt study/
  git commit -m "Platform v1.0.2-RC3"
  git tag -a v1.0.1 -m "Release v1.0.1"
  ```
- [ ] Verify git tag created: `git tag -l`
- [ ] Push to remote

---

## v1.0.2-RC3 - Development Environment Setup (Rejected)

### Installation
- [ ] Run installer on clean system - verify no errors
- [ ] Check git repo created with correct tag (v1.0.1)
- [ ] Verify requirements.txt exists at repo root
- [ ] Confirm .gitignore updated with Wing entries (*.wpr~, .wingide/)
- [ ] Verify old structure rollback works if applicable
- [ ] Test version control copy feature
- [ ] Verify install.log captures full installer output (not just bootstrap)
- [ ] Confirm requirements.txt mentioned in manual git add command

### Bootstrap Execution  
- [ ] Verify via install.log that bootstrap ran successfully
- [ ] Check venv created at `~/.venvs/paip` (NOT repo root)
- [ ] Verify packages installed: `~/.venvs/paip/Scripts/pip list` shows pandas, numpy, openpyxl
- [ ] Check environment variables set correctly via PowerShell/terminal:
  - [ ] `$env:GITHUB_HOME` or `echo $GITHUB_HOME` shows correct path
  - [ ] `$env:PAIP_HOME` or `echo $PAIP_HOME` shows repo path
  - [ ] `$env:PATTERNS_REPO` or `echo $PATTERNS_REPO` shows correct path
  - [ ] `$env:PATTERNS_TOOLS` or `echo $PATTERNS_TOOLS` shows correct path
- [ ] Confirm .wpr file generated at repo root
- [ ] Confirm .wpu file generated at repo root
- [ ] Verify .wpu contains correct Python path to `~/.venvs/paip/Scripts/python.exe` (Windows) or `~/.venvs/paip/bin/python` (Unix)
- [ ] Verify .wpr contains `proj.pypath` with platform/content
- [ ] Verify .wpr sets debug initial directory to study/
- [ ] Confirm activate_env.txt helper created with correct paths

### Wing IDE Integration
- [ ] Open .wpr file in Wing Pro
- [ ] Verify Python interpreter auto-detected (bottom status bar shows venv path)
- [ ] Create simple script in study/practice_work/ and run with F5
- [ ] Check project tree excludes venv/, __pycache__, .git/, .venvs/
- [ ] Test imports work: `from src.patterns_and_gotchas import CorePatterns`
- [ ] Test imports work: `from src.exercises import exercise_1_1`
- [ ] Verify debugging breakpoints work in study/ scripts
- [ ] Verify Wing can import platform content modules without errors

### Documentation Accuracy
- [ ] All docs have version headers (v1.0.2-RC3)
- [ ] GETTING_STARTED.md does NOT recommend manual bootstrap run
- [ ] GETTING_STARTED.md shows automatic setup flow
- [ ] README.md references v1.0.2-RC3
- [ ] Activation commands show user-level venv path
- [ ] ROADMAP.md shows RC8 status correctly
- [ ] RELEASE_NOTES.md has RC8 entry
- [ ] PLATFORM_ARCHITECTURE.md documents PYTHONPATH fix

### Content Integrity
- [ ] All 60 exercises present in platform/content/src/exercises.py
- [ ] All patterns present in platform/content/src/patterns_and_gotchas.py
- [ ] Flashcards file exists in platform/content/data/
- [ ] All doc files present in platform/content/docs/
- [ ] Study folder structure intact (practice_work/, notes/, mock_interviews/)

### Edge Cases & Idempotency
- [ ] Run bootstrap twice - should be idempotent (no errors, detects existing venv)
- [ ] Delete .wpr/.wpu, run bootstrap again - should regenerate with PYTHONPATH
- [ ] Test on Windows path with spaces
- [ ] Test with existing venv at `~/.venvs/paip` - should detect and use
- [ ] Test git clean operations - venv should survive

### Critical Failure Scenarios
- [ ] Bootstrap fails to create user-level venv (check permissions)
- [ ] Wing can't find Python interpreter (check .wpu path format)
- [ ] Imports fail (check .wpr proj.pypath configuration)
- [ ] Hardcoded paths break on different systems
- [ ] Brace artifacts present after installation (should be cleaned)
- [ ] requirements.txt missing from repo root

### Platform Compatibility
- [ ] Windows 10/11 with PowerShell
- [ ] Windows with path containing spaces
- [ ] Windows with OneDrive Documents folder
- [ ] macOS (if applicable)
- [ ] Linux (if applicable)

### Regression from v1.0.0
- [ ] All exercises still runnable
- [ ] Patterns library intact
- [ ] Flashcards accessible
- [ ] Documentation complete
- [ ] Git integration works

### Usage Testing (Developer Perspective)
- [ ] Complete Module 1 Exercise 1 end-to-end in study/practice_work/
- [ ] Import and use CorePatterns in a new script
- [ ] Run exercises.py directly from platform/content/src/
- [ ] Verify Wing debugging works (set breakpoint, step through code)
- [ ] Test git workflow: add study files, commit, verify platform excluded
- [ ] Activate/deactivate venv multiple times
- [ ] Verify flashcards accessible and readable
- [ ] Test documentation links and cross-references
- [ ] Verify no import errors in Wing IDE

### Real-World QA Validation
- [ ] [To be filled during QA based on real usage findings]

### QA Certification
**After ALL checklist items pass:**
- [ ] Manually run git operations:
  ```
  git add platform/ .gitignore README.md requirements.txt activate_env.txt study/
  git commit -m "Platform v1.0.2-RC3"
  git tag -a v1.0.1 -m "Release v1.0.1"
  ```
- [ ] Verify git tag created: `git tag -l`
- [ ] Push to remote if applicable

---

## v1.0.2-RC3 - Development Environment Setup (Rolled Back)

### Installation
- [X] Run installer on clean system - verify no errors
- [ ] Check git repo created with correct tag (v1.0.1)
- [X] Verify requirements.txt exists at repo root
- [X] Confirm .gitignore updated with Wing entries (*.wpr~, .wingide/)
- [X] Verify old structure rollback works if applicable
- [X] Test version control copy feature

### Bootstrap Execution
- [ ] Run `python platform/tools/bootstrap.py`
- [X] Verify venv created at `~/.venvs/paip` (NOT repo root)
- [X] Check packages installed: `~/.venvs/paip/Scripts/pip list` shows pandas, numpy, openpyxl
- [X] Verify environment variables set correctly:
  - [ ] `echo $env:GITHUB_HOME` (PowerShell) or `echo $GITHUB_HOME` (Bash) shows correct path
  - [ ] `echo $env:PATTERNS_REPO` (PowerShell) or `echo $PATTERNS_REPO` (Bash) shows correct path
  - [ ] `echo $env:PATTERNS_TOOLS` (PowerShell) or `echo $PATTERNS_TOOLS` (Bash) shows correct path
- [X] Confirm .wpr file generated at repo root
- [X] Confirm .wpu file generated at repo root
- [X] Check .wpu contains correct Python path to `~/.venvs/paip/Scripts/python.exe` (Windows) or `~/.venvs/paip/bin/python` (Unix)
- [X] Verify activate_env.txt helper created with correct paths

### Wing IDE Integration
- [X] Open .wpr file in Wing Pro
- [X] Verify Python interpreter auto-detected (bottom status bar shows venv path)
- [X] Create simple script in study/practice_work/ and run with F5
- [X] Check project tree excludes venv/, __pycache__, .git/
- [ ] Verify imports work: `from src.patterns_and_gotchas import CorePatterns`
- [ ] Test debugging breakpoints work

### Documentation Accuracy
- [X] GETTING_STARTED.md references v1.0.1
- [X] Activation commands show user-level venv path
- [X] ROADMAP.md exists and renders correctly
- [X] RELEASE_NOTES.md shows v1.0.1 as current
- [X] PLATFORM_ARCHITECTURE.md updated with user-level venv rationale 

### Content Integrity
- [ ] All 60 exercises present in platform/content/src/exercises.py
- [ ] All patterns present in platform/content/src/patterns_and_gotchas.py
- [ ] Flashcards file exists in platform/content/data/
- [ ] All 8 doc files present in platform/content/docs/
- [ ] Study folder structure intact (practice_work/, notes/, mock_interviews/)

### Edge Cases & Idempotency
- [ ] Run bootstrap twice - should be idempotent (no errors, detects existing venv)
- [ ] Delete .wpr/.wpu, run bootstrap again - should regenerate
- [ ] Test on Windows path with spaces
- [ ] Test with existing venv at `~/.venvs/paip` - should detect and use
- [ ] Test git clean operations - venv should survive

### Critical Failure Scenarios
- [ ] Bootstrap fails to create user-level venv (check permissions)
- [ ] Wing can't find Python interpreter (check .wpu path format)
- [ ] Hardcoded paths break on different systems
- [ ] Brace artifacts present after installation (should be cleaned)
- [ ] requirements.txt missing from repo root

### Platform Compatibility
- [ ] Windows 10/11 with PowerShell
- [ ] Windows with path containing spaces
- [ ] macOS (if applicable)
- [ ] Linux (if applicable)

### Regression from v1.0.0
- [ ] All exercises still runnable
- [ ] Patterns library intact
- [ ] Flashcards accessible
- [ ] Documentation complete
- [ ] Git integration works

### Usage Testing (Developer Perspective)
- [ ] Complete Module 1 Exercise 1 end-to-end in study/practice_work/
- [ ] Import and use CorePatterns in a new script
- [ ] Run exercises.py directly from platform/content/src/
- [ ] Verify Wing debugging works (set breakpoint, step through code)
- [ ] Test git workflow: add study files, commit, verify platform excluded
- [ ] Activate/deactivate venv multiple times
- [ ] Verify flashcards accessible and readable
- [ ] Test documentation links and cross-references

### Real-World QA Validation
This section filled in by QA during certification based on actual usage patterns discovered:
- [ ] [To be filled during QA based on real usage findings]

**RC7 Status:** Rolled back due to import errors. PYTHONPATH not configured in .wpr file.

---

## v1.0.0 - Initial Complete Release

### Installation
- [ ] Installer runs without errors
- [ ] Platform extracted to correct location
- [ ] Git repository initialized
- [ ] Tag v1.0.0 created
- [ ] study/ workspace created with .gitkeep files

### Content Validation
- [ ] 60 exercises across 6 modules present
- [ ] Pattern library complete (20+ patterns)
- [ ] Flashcards file exists (60 cards)
- [ ] 8-week course schedule present
- [ ] All documentation files present

### Structure
- [ ] platform/tools/ exists with bootstrap.py
- [ ] platform/content/src/ contains exercises.py and patterns_and_gotchas.py
- [ ] platform/content/docs/ contains all 7 documentation files
- [ ] platform/content/patterns/ structure correct
- [ ] platform/content/data/ contains flashcards
- [ ] study/ workspace created with correct subdirectories

### Git Configuration
- [ ] .gitignore excludes venv/, __pycache__, study content
- [ ] autocrlf set to false
- [ ] No CRLF warnings on commit

---

## Testing Notes

### Test Environments
Document which environments each version was tested on:
- v1.0.2-RC3: [To be filled during QA]
- v1.0.2-RC3: Windows 10, PowerShell, OneDrive Documents
- v1.0.0: [To be filled during QA]

### Known Issues Log
Track issues discovered during QA that aren't release blockers:
- v1.0.2-RC3: Import errors - PYTHONPATH not in .wpr (blocker - rolled back)
- v1.0.2-RC3: requirements.txt not in git add command (fixed in RC8)

### Test Data
Any specific test scenarios or edge cases discovered during QA should be documented here for future regression testing.
