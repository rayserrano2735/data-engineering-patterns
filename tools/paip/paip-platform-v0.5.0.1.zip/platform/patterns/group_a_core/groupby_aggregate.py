"""
PATTERN: Group by and aggregate
GROUP: A (Critical)
WHEN TO USE: "Calculate metrics by category", "Summarize per group"
KEYWORDS: groupby, aggregate, sum, mean, count, by category
INTERVIEW FREQUENCY: Very High (80%+ of interviews)
"""
import pandas as pd

def basic_groupby(df, group_col, agg_col, agg_func='sum'):
    """
    Simple groupby with single aggregation
    """
    return df.groupby(group_col)[agg_col].agg(agg_func).reset_index()

# STARTER CODE:
# df.groupby('category')['sales'].sum()

def multi_metric_agg(df, group_col, agg_dict):
    """
    Multiple aggregations at once
    
    Example:
        agg_dict = {
            'sales': ['sum', 'mean', 'count'],
            'quantity': ['sum']
        }
    """
    result = df.groupby(group_col).agg(agg_dict).reset_index()
    result.columns = ['_'.join(col).strip('_') if col[1] else col[0] 
                      for col in result.columns.values]
    return result

if __name__ == "__main__":
    data = {
        'category': ['A', 'A', 'B', 'B', 'C'],
        'sales': [100, 150, 200, 80, 120],
        'quantity': [10, 15, 20, 8, 12]
    }
    df = pd.DataFrame(data)
    
    print(basic_groupby(df, 'category', 'sales', 'sum'))
