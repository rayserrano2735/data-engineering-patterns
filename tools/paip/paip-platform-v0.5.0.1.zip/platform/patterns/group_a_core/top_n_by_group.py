"""
PATTERN: Top N items per category
GROUP: A (Critical)
WHEN TO USE: "Find top 5 products per region", "Best performing X by Y"
KEYWORDS: top, best, highest, per, by category, rank
INTERVIEW FREQUENCY: Very High (60%+ of interviews)
"""
import pandas as pd

def top_n_by_group(df, group_col, value_col, n=10, ascending=False):
    """
    Get top N items within each group
    
    Time Complexity: O(n log n) for sorting
    Space Complexity: O(n)
    """
    return (df.sort_values(value_col, ascending=ascending)
            .groupby(group_col, as_index=False)
            .head(n)
            .reset_index(drop=True))

# STARTER CODE (30 seconds):
# df.sort_values('sales', ascending=False).groupby('region').head(5)

if __name__ == "__main__":
    data = {
        'region': ['East', 'East', 'East', 'West', 'West', 'West'],
        'product': ['A', 'B', 'C', 'D', 'E', 'F'],
        'sales': [100, 150, 80, 200, 90, 120]
    }
    df = pd.DataFrame(data)
    
    result = top_n_by_group(df, 'region', 'sales', n=2)
    print(result)
