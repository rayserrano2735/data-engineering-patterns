#!/usr/bin/env python3
"""
Python Analytics Interview Prep - Sample Exercises (v0.5.0.1)
10 exercises demonstrating the platform structure
"""

import pandas as pd
import numpy as np

def exercise_1_1():
    """EASY: Create a list of numbers 1-10 and return only even numbers."""
    numbers = list(range(1, 11))
    evens = [n for n in numbers if n % 2 == 0]
    print(f"Result: {evens}")
    return evens

def exercise_1_2():
    """MEDIUM: Remove duplicates from list preserving order."""
    data = [1, 2, 2, 3, 3, 3, 4]
    seen = set()
    unique = []
    for item in data:
        if item not in seen:
            seen.add(item)
            unique.append(item)
    print(f"Result: {unique}")
    return unique

def exercise_2_1():
    """EASY: Square positive numbers using comprehension."""
    numbers = [-2, -1, 0, 1, 2, 3]
    squares = [x**2 for x in numbers if x > 0]
    print(f"Result: {squares}")
    return squares

def exercise_2_2():
    """MEDIUM: Create dict with name lengths."""
    names = ["Alice", "Bob", "Charlie"]
    name_lengths = {name: len(name) for name in names}
    print(f"Result: {name_lengths}")
    return name_lengths

def exercise_3_1():
    """EASY: Lambda with sorted."""
    data = [('Alice', 85), ('Bob', 92), ('Charlie', 78)]
    sorted_data = sorted(data, key=lambda x: x[1], reverse=True)
    print(f"Result: {sorted_data}")
    return sorted_data

def exercise_4_1():
    """EASY: GroupBy sum with pandas."""
    df = pd.DataFrame({
        'category': ['A', 'B', 'A', 'B'],
        'value': [10, 20, 30, 40]
    })
    result = df.groupby('category')['value'].sum()
    print(f"Result:\n{result}")
    return result

def exercise_4_2():
    """MEDIUM: Top 2 per group."""
    df = pd.DataFrame({
        'region': ['East', 'East', 'West', 'West', 'East'],
        'sales': [100, 150, 200, 120, 80]
    })
    result = df.sort_values('sales', ascending=False).groupby('region').head(2)
    print(f"Result:\n{result}")
    return result

def exercise_5_1():
    """EASY: Handle missing values."""
    df = pd.DataFrame({
        'A': [1, 2, None, 4],
        'B': [5, None, 7, 8]
    })
    df_filled = df.fillna(0)
    print(f"Result:\n{df_filled}")
    return df_filled

def exercise_6_1():
    """EASY: Bubble sort without .sort()."""
    arr = [64, 34, 25, 12]
    n = len(arr)
    for i in range(n):
        for j in range(i + 1, n):
            if arr[i] > arr[j]:
                arr[i], arr[j] = arr[j], arr[i]
    print(f"Result: {arr}")
    return arr

def exercise_6_2():
    """MEDIUM: Manual groupby with dict."""
    data = [
        {'cat': 'A', 'val': 10},
        {'cat': 'B', 'val': 20},
        {'cat': 'A', 'val': 30}
    ]
    groups = {}
    for item in data:
        key = item['cat']
        if key not in groups:
            groups[key] = []
        groups[key].append(item['val'])
    
    # Sum each group
    result = {k: sum(v) for k, v in groups.items()}
    print(f"Result: {result}")
    return result

if __name__ == "__main__":
    print("=" * 60)
    print("PYTHON ANALYTICS INTERVIEW PREP - SAMPLE EXERCISES")
    print("v0.5.0.1 - 10 exercises demonstrating platform")
    print("=" * 60)
    print("\nRun individual exercises:")
    print("  exercise_1_1()")
    print("  exercise_4_2()")
    print("\nFull content coming in v0.6.0!")
