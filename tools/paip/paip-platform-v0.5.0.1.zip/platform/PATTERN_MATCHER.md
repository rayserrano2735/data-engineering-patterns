# Pattern Matcher: Interview Problem Recognition Guide

## Purpose
Map interview questions to solution patterns in under 10 seconds.

## Quick Keyword Reference

### 🎯 Ranking & Top-N
**Triggers:** "top", "best", "highest", "per category", "by group"  
**Pattern:** `patterns/group_a_core/top_n_by_group.py`  
**Starter:** `df.sort_values().groupby().head()`

### 📊 Aggregation
**Triggers:** "sum", "average", "count", "by category", "per group"  
**Pattern:** `patterns/group_a_core/groupby_aggregate.py`  
**Starter:** `df.groupby('col')['value'].sum()`

## Interview Flow Strategy

### Minutes 0-2: Understand
1. Identify trigger keywords
2. Ask clarifying questions

### Minutes 2-5: Starter Code
1. Write 3-5 lines of starter code
2. Get SOMETHING working

### Minutes 5-15: Refine
1. Handle edge cases
2. Test with example data

## Pre-Interview Checklist

- ☐ Write top-N-by-group from memory (30 sec)
- ☐ Write basic groupby from memory (20 sec)
- ☐ Explain O(n) vs O(n²) clearly

*Full content coming in v0.6.0!*
