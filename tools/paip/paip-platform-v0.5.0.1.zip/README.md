# Python Analytics Interview Prep Platform

## Quick Start

**Fresh Install:**
```bash
# Download platform-v0.5.0.1.zip and install.bat
# Run install.bat
# Platform installed!
```

**Structure:**
```
python-analytics-interview-prep/
├── platform/              # Course materials (updated via releases)
│   ├── src/              # Python source code
│   ├── patterns/         # Interview patterns
│   ├── docs/             # Documentation (coming in v0.6.0)
│   ├── data/             # Data files (coming in v0.6.0)
│   └── tools/            # Utility scripts (coming in v0.6.0)
└── study/                # YOUR workspace (never overwritten)
    ├── practice_work/    # Your solutions
    ├── notes/            # Your notes
    └── mock_interviews/  # Practice sessions
```

## What's in v0.5.0.1

This is a **patch release** fixing .gitignore bug from v0.5.0:
- ✅ Fixed: .gitignore now properly tracks study/ directory
- ✅ Same minimal content (proof of concept)
- ✅ 10 sample exercises
- ✅ 2 core patterns

## Getting Started

1. Review Pattern Matcher: `platform/PATTERN_MATCHER.md`
2. Try exercises: `python platform/src/exercises.py`
3. Study patterns in `platform/patterns/`

## Coming Soon

**v0.6.0 will include:**
- Full 60-exercise set
- Complete pattern library
- Course documentation
- Flashcards
- Docker environment

## Updates

Download new releases and run install.bat.
Your work in `study/` is always preserved.

## Support

For issues, see platform/PATTERN_MATCHER.md for quick reference.
