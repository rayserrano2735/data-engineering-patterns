# Release Notes

## v1.0.1 (Current)

**Released:** October 3, 2025

### Development Environment Improvements

**User-Level Virtual Environment:**
- venv now created at `~/.venvs/paip` instead of repo root
- Survives git clean operations
- Can be shared across multiple repo clones
- Cleaner repository structure

**Wing IDE Auto-Configuration:**
- Bootstrap generates .wpr (project file) automatically
- Bootstrap generates .wpu (user preferences) with correct Python interpreter
- Proper source path configuration
- Exclusions for faster IDE performance
- No manual Wing setup required

**Platform:**
- `requirements.txt` now at repository root (standard location)
- Updated `.gitignore` for Wing backup files (*.wpr~, .wingide/)
- Improved bootstrap automation

**Documentation:**
- Complete GETTING_STARTED.md rewrite for new venv location
- ROADMAP.md added for feature planning
- Platform architecture updated with user-level venv rationale

## v1.0.0

**Released:** October 3, 2025

### First Complete Release

**Content:**
- 60 exercises across 6 modules (exercises.py)
- 20+ core pandas patterns library (patterns_and_gotchas.py)
- 8-week curriculum with schedule
- 60 interview flashcards
- Complete documentation suite

**Documentation:**
- Platform architecture guide
- Getting started guide
- Course with schedule
- Quick reference
- Talking points
- Learning guide
- Release notes

**Platform:**
- Bootstrap automation script
- Installer with artifact cleanup
- Git autocrlf configuration
- Version control copy feature

**Structure:**
```
platform/
  tools/       - Bootstrap, Docker placeholder
  content/
    src/       - Exercises and patterns (populated)
    docs/      - Full documentation (7 files)
    patterns/  - Pattern library (8 files)
    data/      - Flashcards
study/         - User workspace
```

## v0.6.3

**Released:** October 3, 2025

### New Features
- Content subdirectories with .gitkeep files (src/, docs/, patterns/, data/)
- Artifact cleanup for brace-expansion folders
- Installation confirmation prompt

### Bug Fixes
- Fixed study folder zip artifact
- Fixed content folder zip artifacts
- Install script now removes unexpected subdirectories

### Improvements
- Complete platform/ folder replacement (no merge)
- CRLF warnings eliminated (autocrlf=false)
- Cleaner installation process

## v0.6.2

**Released:** October 3, 2025

### Changes
- Complete platform/ folder replacement strategy
- Git autocrlf configuration
- Installation abort prompt

## v0.6.1

**Released:** October 3, 2025

### Changes
- Removed architecture/ folder
- Simplified to tools/ and content/ structure
- Added bootstrap.py for environment automation
- Docker folder placeholder

## v0.6.0

**Released:** October 3, 2025
**Status:** Never pushed

### Changes
- Initial architecture/ and content/ split
- Not used in production

## v0.5.0.1

### Features
- Flat platform structure
- Basic installation workflow
- Version control copy feature

## Earlier Versions

Pre-v0.5 versions used various flat structures without the platform/ organization.

## Upgrade Path

### From v0.5.x to v0.6.3
- Download v0.6.3 installer and zip
- Run installer (auto-detects old structure)
- Old files moved to Downloads/paip-rollback-[date]
- study/ workspace preserved

### From v0.6.0-v0.6.2 to v0.6.3
- Same process as above
- Platform replaced completely
- Artifacts cleaned automatically

## Known Issues

### v0.6.3
- KB file loading inconsistent for some files
- Workaround: Upload files directly to chat

### All Versions
- Bootstrap requires manual shell restart to activate environment variables
- Virtual environment must be manually activated before use

## Future Releases

### Planned for v0.7.x
- Docker environment setup
- Enhanced content organization
- Improved KB integration

### Under Consideration
- Automated testing
- GitHub Releases integration
- Context management tools
