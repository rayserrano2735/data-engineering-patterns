#!/usr/bin/env python3
"""
Python Analytics Engineering Interview Prep - Exercises
60 exercises (10 per module) with solutions and explanations
Progressive difficulty: Easy → Medium → Hard → Debug → Interview
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Tuple
import json

# ============================================================================
# MODULE 1: DATA STRUCTURES & OPERATIONS
# ============================================================================

def exercise_1_1():
    """
    EASY: Create a list of numbers 1-10 and return only even numbers.
    Time: 5 minutes
    """
    # Problem
    print("Create a list of numbers 1-10 and return only even numbers.")
    
    # Your solution here:
    # numbers = ???
    # evens = ???
    
    # Solution
    numbers = list(range(1, 11))  # [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    # Method 1: List comprehension (best)
    evens = [n for n in numbers if n % 2 == 0]
    
    # Method 2: Filter
    evens_filter = list(filter(lambda x: x % 2 == 0, numbers))
    
    # Method 3: Loop (verbose but clear)
    evens_loop = []
    for n in numbers:
        if n % 2 == 0:
            evens_loop.append(n)
    
    print(f"Result: {evens}")  # [2, 4, 6, 8, 10]
    return evens

def exercise_1_2():
    """
    MEDIUM: Given a list with duplicates [1, 2, 2, 3, 3, 3, 4], 
    return unique values in original order.
    Time: 8 minutes
    """
    # Problem
    data = [1, 2, 2, 3, 3, 3, 4]
    print(f"Remove duplicates from {data}, preserving order")
    
    # Solution
    # Method 1: Dict.fromkeys() trick (Python 3.7+ preserves order)
    unique = list(dict.fromkeys(data))
    
    # Method 2: Manual tracking (more explicit)
    seen = set()
    unique_manual = []
    for item in data:
        if item not in seen:
            seen.add(item)
            unique_manual.append(item)
    
    # Method 3: Using pandas (overkill but works)
    unique_pandas = pd.Series(data).drop_duplicates().tolist()
    
    print(f"Result: {unique}")  # [1, 2, 3, 4]
    
    # Explanation: Order matters! set(data) would lose order.
    return unique

def exercise_1_3():
    """
    HARD: Merge two dictionaries, but if keys overlap, keep the higher value.
    Time: 10 minutes
    """
    # Problem
    dict1 = {'a': 10, 'b': 20, 'c': 30}
    dict2 = {'b': 25, 'c': 15, 'd': 40}
    print(f"Merge {dict1} and {dict2}, keeping higher values")
    
    # Solution
    # Method 1: Iterate and compare
    merged = dict1.copy()
    for key, value in dict2.items():
        if key not in merged or value > merged[key]:
            merged[key] = value
    
    # Method 2: Using dict comprehension with union
    all_keys = set(dict1.keys()) | set(dict2.keys())
    merged_comp = {
        key: max(dict1.get(key, float('-inf')), 
                dict2.get(key, float('-inf')))
        for key in all_keys
    }
    
    print(f"Result: {merged}")  # {'a': 10, 'b': 25, 'c': 30, 'd': 40}
    
    # Explanation: b=25 (not 20), c=30 (not 15), d=40 (new)
    return merged

def exercise_1_4():
    """
    DEBUG: Fix this code that should remove duplicates from a list.
    Time: 7 minutes
    """
    # Broken code
    def remove_duplicates_broken(items):
        # BUG: Modifying list while iterating
        for i, item in enumerate(items):
            if items.count(item) > 1:
                items.remove(item)
        return items
    
    # Problem demonstration
    test_data = [1, 2, 2, 3, 3, 3, 4]
    # result = remove_duplicates_broken(test_data.copy())
    # This would skip elements!
    
    # Fixed solution
    def remove_duplicates_fixed(items):
        # Option 1: Use set (loses order)
        # return list(set(items))
        
        # Option 2: Preserve order
        seen = set()
        result = []
        for item in items:
            if item not in seen:
                seen.add(item)
                result.append(item)
        return result
    
    result = remove_duplicates_fixed(test_data)
    print(f"Fixed result: {result}")  # [1, 2, 3, 4]
    
    # Explanation: Never modify a list while iterating over it!
    return result

def exercise_1_5():
    """
    INTERVIEW: Count frequency of words in a sentence using a dictionary.
    Handle case-insensitive matching and punctuation.
    Time: 12 minutes
    """
    # Problem
    sentence = "The quick brown fox jumps over the lazy dog. The fox is quick!"
    print(f"Count word frequency in: {sentence}")
    
    # Solution
    import string
    
    # Clean and split
    # Remove punctuation and convert to lowercase
    cleaned = sentence.lower().translate(
        str.maketrans('', '', string.punctuation)
    )
    words = cleaned.split()
    
    # Method 1: Manual dictionary building
    frequency = {}
    for word in words:
        frequency[word] = frequency.get(word, 0) + 1
    
    # Method 2: Using Counter (best practice)
    from collections import Counter
    frequency_counter = Counter(words)
    
    # Method 3: Using defaultdict
    from collections import defaultdict
    frequency_default = defaultdict(int)
    for word in words:
        frequency_default[word] += 1
    
    # Sort by frequency (common interview addition)
    sorted_freq = dict(sorted(frequency.items(), 
                             key=lambda x: x[1], 
                             reverse=True))
    
    print(f"Word frequencies: {sorted_freq}")
    # {'the': 2, 'quick': 2, 'fox': 2, ...}
    
    return sorted_freq

# ============================================================================
# MODULE 2: LIST COMPREHENSIONS & STRING OPERATIONS
# ============================================================================

def exercise_2_1():
    """
    EASY: Use list comprehension to get squares of only positive numbers 
    from [-2, -1, 0, 1, 2, 3].
    Time: 5 minutes
    """
    # Problem
    numbers = [-2, -1, 0, 1, 2, 3]
    print(f"Get squares of positive numbers from {numbers}")
    
    # Solution
    # Note: 0 is not positive!
    squares = [x**2 for x in numbers if x > 0]
    
    # Common mistake (includes 0)
    # wrong = [x**2 for x in numbers if x >= 0]
    
    print(f"Result: {squares}")  # [1, 4, 9]
    
    # Alternative: Include transformation in condition
    squares_alt = [x**2 for x in numbers if x > 0]
    
    return squares

def exercise_2_2():
    """
    MEDIUM: Given list of names, create dictionary with name as key 
    and name length as value.
    Time: 7 minutes
    """
    # Problem
    names = ["Alice", "Bob", "Charlie", "Dave", "Eve"]
    print(f"Create length dictionary from {names}")
    
    # Solution
    # Dictionary comprehension
    name_lengths = {name: len(name) for name in names}
    
    # Alternative: Using zip
    name_lengths_zip = dict(zip(names, map(len, names)))
    
    # Filter variant: Only names longer than 3 chars
    long_names = {name: len(name) for name in names if len(name) > 3}
    
    print(f"Result: {name_lengths}")
    # {'Alice': 5, 'Bob': 3, 'Charlie': 7, 'Dave': 4, 'Eve': 3}
    
    return name_lengths

def exercise_2_3():
    """
    HARD: Flatten this nested structure [1, [2, 3], [4, [5, 6]], 7] 
    to [1, 2, 3, 4, 5, 6, 7].
    Time: 12 minutes
    """
    # Problem
    nested = [1, [2, 3], [4, [5, 6]], 7]
    print(f"Flatten nested structure: {nested}")
    
    # Solution
    def flatten(lst):
        """Recursively flatten nested list"""
        result = []
        for item in lst:
            if isinstance(item, list):
                result.extend(flatten(item))
            else:
                result.append(item)
        return result
    
    flat = flatten(nested)
    
    # Alternative: Using generator for memory efficiency
    def flatten_gen(lst):
        for item in lst:
            if isinstance(item, list):
                yield from flatten_gen(item)
            else:
                yield item
    
    flat_gen = list(flatten_gen(nested))
    
    print(f"Result: {flat}")  # [1, 2, 3, 4, 5, 6, 7]
    
    # Note: For single-level nesting, use:
    # flat_simple = [item for sublist in nested for item in sublist]
    
    return flat

def exercise_2_4():
    """
    DEBUG: Fix the comprehension that should get words longer than 3 characters.
    Time: 5 minutes
    """
    # Broken code
    sentence = "The quick brown fox jumps"
    # wrong = [word for word in sentence if len(word) > 3]
    # BUG: Iterates over characters, not words!
    
    # Fixed solution
    words_correct = [word for word in sentence.split() if len(word) > 3]
    
    # Additional: Handle punctuation
    import string
    sentence_punct = "The quick, brown fox jumps!"
    words_clean = [
        word.strip(string.punctuation) 
        for word in sentence_punct.split() 
        if len(word.strip(string.punctuation)) > 3
    ]
    
    print(f"Result: {words_correct}")  # ['quick', 'brown', 'jumps']
    
    return words_correct

def exercise_2_5():
    """
    INTERVIEW: Clean email addresses - lowercase, remove spaces, validate format.
    Return list of (email, is_valid) tuples.
    Time: 10 minutes
    """
    # Problem
    emails = [
        "  Alice@Example.COM  ",
        "bob@domain",
        "charlie@email.co.uk",
        "not.an.email",
        "dave@",
        "eve@company.org"
    ]
    print(f"Clean and validate emails: {emails}")
    
    # Solution
    def clean_and_validate(email_list):
        result = []
        
        for email in email_list:
            # Clean
            cleaned = email.strip().lower()
            
            # Validate (simple check)
            is_valid = (
                '@' in cleaned and 
                '.' in cleaned.split('@')[1] if '@' in cleaned else False
            )
            
            result.append((cleaned, is_valid))
        
        return result
    
    # Using list comprehension
    def validate_email(email):
        email = email.strip().lower()
        parts = email.split('@')
        return (
            len(parts) == 2 and 
            len(parts[0]) > 0 and 
            '.' in parts[1]
        )
    
    cleaned_emails = [
        (email.strip().lower(), validate_email(email))
        for email in emails
    ]
    
    print(f"Result: {cleaned_emails}")
    # [('alice@example.com', True), ('bob@domain', False), ...]
    
    return cleaned_emails

# ============================================================================
# MODULE 3: FUNCTIONS & LAMBDA
# ============================================================================

def exercise_3_1():
    """
    EASY: Write a function with default parameters that formats 
    a number as currency.
    Time: 5 minutes
    """
    # Solution
    def format_currency(amount, symbol='$', decimals=2, thousands_sep=','):
        """
        Format number as currency with customizable options.
        
        Args:
            amount: Numeric value
            symbol: Currency symbol (default: $)
            decimals: Decimal places (default: 2)
            thousands_sep: Thousands separator (default: ,)
        """
        # Format with thousands separator and decimals
        formatted = f"{amount:,.{decimals}f}"
        
        # Add currency symbol
        return f"{symbol}{formatted}"
    
    # Test
    print(format_currency(1234567.89))  # $1,234,567.89
    print(format_currency(1234567.89, symbol='€'))  # €1,234,567.89
    print(format_currency(1234567.89, decimals=0))  # $1,234,568
    
    return format_currency

def exercise_3_2():
    """
    MEDIUM: Use lambda with sorted() to sort list of tuples by second element.
    Time: 7 minutes
    """
    # Problem
    data = [
        ('Alice', 85),
        ('Bob', 92),
        ('Charlie', 78),
        ('Dave', 92),
        ('Eve', 88)
    ]
    print(f"Sort by score: {data}")
    
    # Solution
    # Sort by second element (score)
    sorted_by_score = sorted(data, key=lambda x: x[1])
    
    # Sort descending
    sorted_desc = sorted(data, key=lambda x: x[1], reverse=True)
    
    # Sort by score (desc), then name (asc) for ties
    sorted_complex = sorted(data, key=lambda x: (-x[1], x[0]))
    
    print(f"Sorted ascending: {sorted_by_score}")
    print(f"Sorted descending: {sorted_desc}")
    print(f"Score desc, name asc: {sorted_complex}")
    
    return sorted_complex

def exercise_3_3():
    """
    HARD: Create a function that returns a function (closure) 
    for custom filtering.
    Time: 10 minutes
    """
    # Solution
    def create_filter(min_value=None, max_value=None, exclude_values=None):
        """
        Create a custom filter function with configured parameters.
        
        Returns a function that filters based on the configured criteria.
        """
        exclude_set = set(exclude_values) if exclude_values else set()
        
        def filter_func(value):
            # Check exclusions first
            if value in exclude_set:
                return False
            
            # Check min boundary
            if min_value is not None and value < min_value:
                return False
            
            # Check max boundary
            if max_value is not None and value > max_value:
                return False
            
            return True
        
        # Return the configured filter
        return filter_func
    
    # Usage examples
    # Create filter for values between 10-100, excluding 50
    my_filter = create_filter(min_value=10, max_value=100, exclude_values=[50])
    
    data = [5, 10, 25, 50, 75, 100, 150]
    filtered = list(filter(my_filter, data))
    print(f"Filtered result: {filtered}")  # [10, 25, 75, 100]
    
    # Create another filter instance
    positive_filter = create_filter(min_value=0)
    positive_nums = list(filter(positive_filter, [-5, -1, 0, 1, 5]))
    print(f"Positive only: {positive_nums}")  # [0, 1, 5]
    
    return create_filter

def exercise_3_4():
    """
    DEBUG: Fix the mutable default argument bug in the provided code.
    Time: 5 minutes
    """
    # Broken code
    def append_to_list_broken(item, target_list=[]):
        """This has a mutable default argument bug!"""
        target_list.append(item)
        return target_list
    
    # Demonstrate the bug
    # list1 = append_to_list_broken(1)  # [1]
    # list2 = append_to_list_broken(2)  # [1, 2] - UNEXPECTED!
    
    # Fixed solution
    def append_to_list_fixed(item, target_list=None):
        """Fixed version using None as default"""
        if target_list is None:
            target_list = []
        target_list.append(item)
        return target_list
    
    # Test the fix
    list1 = append_to_list_fixed(1)  # [1]
    list2 = append_to_list_fixed(2)  # [2] - CORRECT!
    list3 = append_to_list_fixed(3, list1)  # [1, 3] - CORRECT!
    
    print(f"list1: {list1}, list2: {list2}, list3: {list3}")
    
    # Explanation: Default mutable arguments are created once at function
    # definition time, not at call time!
    
    return append_to_list_fixed

def exercise_3_5():
    """
    INTERVIEW: Use map, filter, and reduce to process a list of transactions.
    Calculate total revenue from valid transactions (amount > 0, status='completed').
    Time: 10 minutes
    """
    # Problem
    transactions = [
        {'id': 1, 'amount': 100, 'status': 'completed'},
        {'id': 2, 'amount': -50, 'status': 'completed'},  # Invalid: negative
        {'id': 3, 'amount': 200, 'status': 'pending'},    # Invalid: pending
        {'id': 4, 'amount': 150, 'status': 'completed'},
        {'id': 5, 'amount': 0, 'status': 'completed'},    # Invalid: zero
        {'id': 6, 'amount': 300, 'status': 'completed'},
    ]
    
    # Solution using functional approach
    from functools import reduce
    
    # Step 1: Filter valid transactions
    valid_transactions = list(filter(
        lambda t: t['amount'] > 0 and t['status'] == 'completed',
        transactions
    ))
    
    # Step 2: Extract amounts using map
    amounts = list(map(lambda t: t['amount'], valid_transactions))
    
    # Step 3: Sum using reduce
    total_revenue = reduce(lambda x, y: x + y, amounts, 0)
    
    print(f"Valid transactions: {len(valid_transactions)}")
    print(f"Total revenue: ${total_revenue}")  # $550
    
    # One-liner version (less readable but impressive)
    total_oneliner = reduce(
        lambda acc, t: acc + t['amount'],
        filter(
            lambda t: t['amount'] > 0 and t['status'] == 'completed',
            transactions
        ),
        0
    )
    
    # Pandas alternative (more practical)
    df = pd.DataFrame(transactions)
    total_pandas = df[
        (df['amount'] > 0) & (df['status'] == 'completed')
    ]['amount'].sum()
    
    return total_revenue

# ============================================================================
# MODULE 4: ESSENTIAL PANDAS OPERATIONS
# ============================================================================

def exercise_4_1():
    """
    EASY: Create a DataFrame and calculate mean salary by department.
    Time: 5 minutes
    """
    # Problem data
    data = {
        'name': ['Alice', 'Bob', 'Charlie', 'Dave', 'Eve', 'Frank'],
        'department': ['Sales', 'IT', 'Sales', 'IT', 'HR', 'IT'],
        'salary': [50000, 75000, 55000, 80000, 45000, 70000]
    }
    
    # Solution
    df = pd.DataFrame(data)
    
    # Calculate mean by department
    mean_salaries = df.groupby('department')['salary'].mean()
    
    # Alternative: Get as DataFrame with reset index
    mean_salaries_df = df.groupby('department')['salary'].mean().reset_index()
    mean_salaries_df.columns = ['department', 'avg_salary']
    
    print("Mean salaries by department:")
    print(mean_salaries)
    
    return mean_salaries

def exercise_4_2():
    """
    MEDIUM: Merge two DataFrames and handle missing values in the result.
    Time: 10 minutes
    """
    # Problem data
    employees = pd.DataFrame({
        'emp_id': [1, 2, 3, 4, 5],
        'name': ['Alice', 'Bob', 'Charlie', 'Dave', 'Eve'],
        'dept_id': [10, 20, 10, 30, 20]
    })
    
    departments = pd.DataFrame({
        'dept_id': [10, 20, 40],  # Note: no dept 30, but has 40
        'dept_name': ['Sales', 'IT', 'Marketing'],
        'budget': [100000, 200000, 150000]
    })
    
    # Solution
    # Left join to keep all employees
    merged = pd.merge(employees, departments, on='dept_id', how='left')
    
    # Handle missing values
    merged['dept_name'] = merged['dept_name'].fillna('Unknown')
    merged['budget'] = merged['budget'].fillna(0)
    
    # Alternative: Outer join to see all departments too
    merged_outer = pd.merge(employees, departments, on='dept_id', how='outer')
    merged_outer['name'] = merged_outer['name'].fillna('No Employee')
    
    print("Merged with missing value handling:")
    print(merged)
    
    return merged

def exercise_4_3():
    """
    HARD: Group by multiple columns and calculate multiple aggregations.
    Time: 12 minutes
    """
    # Problem data - sales transactions
    sales = pd.DataFrame({
        'date': pd.date_range('2024-01-01', periods=100, freq='D'),
        'region': np.random.choice(['North', 'South', 'East', 'West'], 100),
        'product': np.random.choice(['A', 'B', 'C'], 100),
        'quantity': np.random.randint(1, 20, 100),
        'price': np.random.uniform(10, 100, 100).round(2)
    })
    sales['revenue'] = sales['quantity'] * sales['price']
    sales['month'] = sales['date'].dt.month
    
    # Solution
    # Group by region and product, multiple aggregations
    summary = sales.groupby(['region', 'product']).agg({
        'quantity': ['sum', 'mean'],
        'revenue': ['sum', 'mean', 'max'],
        'price': ['mean', 'std']
    }).round(2)
    
    # Flatten column names
    summary.columns = ['_'.join(col) for col in summary.columns]
    summary = summary.reset_index()
    
    # Alternative: Named aggregations (cleaner)
    summary_clean = sales.groupby(['region', 'product']).agg(
        total_quantity=('quantity', 'sum'),
        avg_quantity=('quantity', 'mean'),
        total_revenue=('revenue', 'sum'),
        avg_revenue=('revenue', 'mean'),
        max_revenue=('revenue', 'max'),
        avg_price=('price', 'mean')
    ).round(2).reset_index()
    
    print("Summary statistics:")
    print(summary_clean.head(10))
    
    return summary_clean

def exercise_4_4():
    """
    DEBUG: Fix the SettingWithCopyWarning in the provided code.
    Time: 7 minutes
    """
    # Broken code that causes warning
    def process_data_broken(df):
        # Filter data
        high_value = df[df['value'] > 100]
        
        # This causes SettingWithCopyWarning!
        high_value['category'] = 'Premium'  # BAD
        
        return high_value
    
    # Fixed solution
    def process_data_fixed(df):
        # Method 1: Use .copy() explicitly
        high_value = df[df['value'] > 100].copy()
        high_value['category'] = 'Premium'
        
        # Method 2: Use .loc for assignment
        df.loc[df['value'] > 100, 'category'] = 'Premium'
        
        # Method 3: Assign with explicit copy
        high_value = df.loc[df['value'] > 100, :].copy()
        high_value['category'] = 'Premium'
        
        return high_value
    
    # Test
    test_df = pd.DataFrame({
        'value': [50, 150, 200, 75, 300],
        'name': ['A', 'B', 'C', 'D', 'E']
    })
    
    result = process_data_fixed(test_df.copy())
    print("Fixed result without warning:")
    print(result)
    
    return result

def exercise_4_5():
    """
    INTERVIEW: Find top 3 products by revenue in each region, 
    excluding nulls and products with less than 10 total sales.
    Time: 15 minutes
    """
    # Generate realistic sales data
    np.random.seed(42)
    n_records = 1000
    
    sales_data = pd.DataFrame({
        'product_id': np.random.choice(['P001', 'P002', 'P003', 'P004', 'P005', 
                                       'P006', 'P007', 'P008', None], n_records),
        'region': np.random.choice(['North', 'South', 'East', 'West', None], n_records),
        'quantity': np.random.randint(1, 20, n_records),
        'price': np.random.uniform(10, 100, n_records)
    })
    
    # Add some products with low sales
    sales_data.loc[sales_data['product_id'] == 'P008', 'quantity'] = 1
    
    # Calculate revenue
    sales_data['revenue'] = sales_data['quantity'] * sales_data['price']
    
    # Solution
    # Step 1: Remove nulls
    clean_data = sales_data.dropna(subset=['product_id', 'region'])
    
    # Step 2: Calculate total sales per product
    product_sales = clean_data.groupby('product_id')['quantity'].sum()
    valid_products = product_sales[product_sales >= 10].index
    
    # Step 3: Filter for valid products only
    valid_data = clean_data[clean_data['product_id'].isin(valid_products)]
    
    # Step 4: Calculate total revenue by region and product
    revenue_summary = valid_data.groupby(['region', 'product_id'])['revenue'].sum().reset_index()
    
    # Step 5: Find top 3 per region
    top_products = (revenue_summary
                    .sort_values('revenue', ascending=False)
                    .groupby('region')
                    .head(3))
    
    # Alternative: Using rank
    revenue_summary['rank'] = (revenue_summary
                               .groupby('region')['revenue']
                               .rank(method='dense', ascending=False))
    top_products_alt = revenue_summary[revenue_summary['rank'] <= 3]
    
    print("Top 3 products by revenue per region:")
    print(top_products.sort_values(['region', 'revenue'], ascending=[True, False]))
    
    return top_products

# ============================================================================
# MODULE 5: FILE I/O & ERROR HANDLING
# ============================================================================

def exercise_5_1():
    """
    EASY: Write a function that safely reads a JSON file 
    and returns empty dict on error.
    Time: 5 minutes
    """
    # Solution
    def read_json_safe(filepath):
        """
        Safely read JSON file with error handling.
        Returns empty dict if any error occurs.
        """
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            return data
        except FileNotFoundError:
            print(f"File not found: {filepath}")
            return {}
        except json.JSONDecodeError as e:
            print(f"Invalid JSON in {filepath}: {e}")
            return {}
        except Exception as e:
            print(f"Unexpected error reading {filepath}: {e}")
            return {}
    
    # Test with various scenarios
    # result1 = read_json_safe('exists.json')  # Normal read
    # result2 = read_json_safe('missing.json')  # Returns {}
    # result3 = read_json_safe('invalid.json')  # Returns {}
    
    print("Function created: read_json_safe()")
    return read_json_safe

def exercise_5_2():
    """
    MEDIUM: Read a CSV file and handle potential encoding errors.
    Time: 8 minutes
    """
    # Solution
    def read_csv_with_encoding(filepath):
        """
        Try multiple encodings to read a CSV file.
        """
        encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252', 'utf-16']
        
        for encoding in encodings:
            try:
                df = pd.read_csv(filepath, encoding=encoding)
                print(f"Successfully read with {encoding} encoding")
                return df
            except UnicodeDecodeError:
                continue
            except FileNotFoundError:
                print(f"File not found: {filepath}")
                return pd.DataFrame()
        
        # If all encodings fail
        print(f"Could not read {filepath} with any standard encoding")
        
        # Last resort: ignore errors (may lose some characters)
        try:
            df = pd.read_csv(filepath, encoding='utf-8', errors='ignore')
            print("Read with errors ignored (some characters may be lost)")
            return df
        except Exception as e:
            print(f"Failed to read file: {e}")
            return pd.DataFrame()
    
    print("Function created: read_csv_with_encoding()")
    return read_csv_with_encoding

def exercise_5_3():
    """
    HARD: Implement retry logic with exponential backoff for API calls.
    Time: 12 minutes
    """
    # Solution
    import time
    import random
    
    def api_call_with_retry(
        api_func, 
        max_retries=3, 
        initial_delay=1,
        max_delay=32,
        exponential_base=2,
        jitter=True
    ):
        """
        Call an API function with retry logic and exponential backoff.
        
        Args:
            api_func: Function to call
            max_retries: Maximum number of retry attempts
            initial_delay: Initial delay in seconds
            max_delay: Maximum delay in seconds
            exponential_base: Base for exponential backoff
            jitter: Add random jitter to prevent thundering herd
        """
        delay = initial_delay
        
        for attempt in range(max_retries + 1):
            try:
                result = api_func()
                if attempt > 0:
                    print(f"Success after {attempt} retries")
                return result
                
            except Exception as e:
                if attempt == max_retries:
                    print(f"Failed after {max_retries} retries: {e}")
                    raise
                
                # Calculate next delay
                if jitter:
                    actual_delay = delay * (0.5 + random.random())
                else:
                    actual_delay = delay
                
                print(f"Attempt {attempt + 1} failed: {e}")
                print(f"Retrying in {actual_delay:.2f} seconds...")
                
                time.sleep(actual_delay)
                
                # Exponential backoff
                delay = min(delay * exponential_base, max_delay)
        
        raise Exception("Retry logic error - should not reach here")
    
    # Example API function that fails sometimes
    def flaky_api():
        if random.random() < 0.7:  # 70% failure rate
            raise ConnectionError("API temporarily unavailable")
        return {"status": "success", "data": [1, 2, 3]}
    
    # Test the retry logic
    # result = api_call_with_retry(flaky_api)
    
    print("Function created: api_call_with_retry()")
    return api_call_with_retry

def exercise_5_4():
    """
    DEBUG: Fix the file handling code that doesn't properly close files.
    Time: 5 minutes
    """
    # Broken code
    def process_file_broken(filepath):
        """This doesn't properly close the file on error!"""
        file = open(filepath, 'r')
        data = file.read()
        
        # If error occurs here, file never closes!
        processed = data.upper()
        
        file.close()
        return processed
    
    # Fixed solution 1: try/finally
    def process_file_fixed_v1(filepath):
        """Using try/finally to ensure file closure"""
        file = None
        try:
            file = open(filepath, 'r')
            data = file.read()
            processed = data.upper()
            return processed
        finally:
            if file:
                file.close()
    
    # Fixed solution 2: context manager (BEST)
    def process_file_fixed_v2(filepath):
        """Using context manager (with statement) - Pythonic way"""
        with open(filepath, 'r') as file:
            data = file.read()
            processed = data.upper()
        # File automatically closed here, even if error occurs
        return processed
    
    print("Fixed versions created using context manager")
    return process_file_fixed_v2

def exercise_5_5():
    """
    INTERVIEW: Process large CSV in chunks and aggregate results.
    Calculate average salary by department from a 10GB file.
    Time: 15 minutes
    """
    # Solution
    def process_large_csv(filepath, chunk_size=10000):
        """
        Process large CSV file in chunks to calculate aggregations.
        Memory-efficient approach for files that don't fit in memory.
        """
        # Initialize aggregators
        department_sums = {}
        department_counts = {}
        
        # Process in chunks
        chunk_num = 0
        
        try:
            for chunk in pd.read_csv(filepath, chunksize=chunk_size):
                chunk_num += 1
                print(f"Processing chunk {chunk_num}...")
                
                # Aggregate within chunk
                chunk_agg = chunk.groupby('department').agg({
                    'salary': ['sum', 'count']
                })
                
                # Merge with overall aggregation
                for dept in chunk_agg.index:
                    salary_sum = chunk_agg.loc[dept, ('salary', 'sum')]
                    salary_count = chunk_agg.loc[dept, ('salary', 'count')]
                    
                    if dept in department_sums:
                        department_sums[dept] += salary_sum
                        department_counts[dept] += salary_count
                    else:
                        department_sums[dept] = salary_sum
                        department_counts[dept] = salary_count
        
        except FileNotFoundError:
            print(f"File not found: {filepath}")
            return pd.DataFrame()
        
        # Calculate final averages
        result = pd.DataFrame({
            'department': list(department_sums.keys()),
            'total_salary': list(department_sums.values()),
            'employee_count': list(department_counts.values())
        })
        
        result['average_salary'] = result['total_salary'] / result['employee_count']
        
        print(f"Processed {chunk_num} chunks")
        print(f"Found {len(result)} departments")
        
        return result[['department', 'average_salary', 'employee_count']]
    
    # Alternative: Using dask for very large files
    def process_with_dask(filepath):
        """Alternative using dask for parallel processing"""
        # import dask.dataframe as dd
        # ddf = dd.read_csv(filepath)
        # result = ddf.groupby('department')['salary'].mean().compute()
        pass
    
    print("Function created: process_large_csv()")
    return process_large_csv

# ============================================================================
# MODULE 6: COMMON GOTCHAS & BEST PRACTICES
# ============================================================================

def exercise_6_1():
    """
    EASY: Implement bubble sort without using .sort() or sorted().
    Time: 8 minutes
    """
    # Solution
    def bubble_sort(arr):
        """
        Implement bubble sort manually.
        Modifies list in-place and returns it.
        """
        n = len(arr)
        
        # Make a copy to avoid modifying original
        result = arr.copy()
        
        # Bubble sort algorithm
        for i in range(n):
            # Flag to optimize by detecting if already sorted
            swapped = False
            
            # Last i elements are already in place
            for j in range(0, n - i - 1):
                if result[j] > result[j + 1]:
                    # Swap elements
                    result[j], result[j + 1] = result[j + 1], result[j]
                    swapped = True
            
            # If no swaps occurred, array is sorted
            if not swapped:
                break
        
        return result
    
    # Test
    test_data = [64, 34, 25, 12, 22, 11, 90]
    sorted_data = bubble_sort(test_data)
    
    print(f"Original: {test_data}")
    print(f"Sorted: {sorted_data}")
    
    # Alternative: Selection sort (also O(n²))
    def selection_sort(arr):
        result = arr.copy()
        n = len(result)
        
        for i in range(n):
            min_idx = i
            for j in range(i + 1, n):
                if result[j] < result[min_idx]:
                    min_idx = j
            result[i], result[min_idx] = result[min_idx], result[i]
        
        return result
    
    return bubble_sort

def exercise_6_2():
    """
    MEDIUM: Group a list of dictionaries by a key without using groupby.
    Time: 10 minutes
    """
    # Problem data
    records = [
        {'name': 'Alice', 'department': 'Sales', 'salary': 50000},
        {'name': 'Bob', 'department': 'IT', 'salary': 75000},
        {'name': 'Charlie', 'department': 'Sales', 'salary': 55000},
        {'name': 'Dave', 'department': 'IT', 'salary': 80000},
        {'name': 'Eve', 'department': 'HR', 'salary': 45000},
    ]
    
    # Solution
    def manual_groupby(data, key_field):
        """
        Manually group records by a specified field.
        Returns dict with keys as group values and values as lists of records.
        """
        groups = {}
        
        for record in data:
            key = record.get(key_field)
            
            if key not in groups:
                groups[key] = []
            
            groups[key].append(record)
        
        return groups
    
    # Group by department
    grouped = manual_groupby(records, 'department')
    
    # Calculate aggregations manually
    dept_stats = {}
    for dept, employees in grouped.items():
        total_salary = sum(emp['salary'] for emp in employees)
        avg_salary = total_salary / len(employees)
        
        dept_stats[dept] = {
            'count': len(employees),
            'total_salary': total_salary,
            'avg_salary': avg_salary,
            'employees': [emp['name'] for emp in employees]
        }
    
    print("Grouped by department:")
    for dept, stats in dept_stats.items():
        print(f"{dept}: {stats}")
    
    return grouped

def exercise_6_3():
    """
    HARD: Flatten an arbitrarily nested list structure.
    Time: 12 minutes
    """
    # Solution
    def flatten_recursive(nested):
        """
        Flatten nested list recursively.
        Handles arbitrary nesting depth.
        """
        result = []
        
        for item in nested:
            if isinstance(item, list):
                # Recursively flatten sublists
                result.extend(flatten_recursive(item))
            else:
                result.append(item)
        
        return result
    
    def flatten_iterative(nested):
        """
        Flatten nested list iteratively using a stack.
        Alternative approach without recursion.
        """
        result = []
        stack = [nested]
        
        while stack:
            current = stack.pop()
            
            if isinstance(current, list):
                # Add list elements to stack in reverse order
                # so they're processed in original order
                stack.extend(reversed(current))
            else:
                result.append(current)
        
        # Reverse since we built it backwards
        return result[::-1]
    
    def flatten_generator(nested):
        """
        Memory-efficient generator version.
        """
        for item in nested:
            if isinstance(item, list):
                yield from flatten_generator(item)
            else:
                yield item
    
    # Test with complex nesting
    complex_nested = [1, [2, 3], [4, [5, [6, 7]], 8], [[[[9]]]], 10]
    
    flat1 = flatten_recursive(complex_nested)
    flat2 = flatten_iterative(complex_nested)
    flat3 = list(flatten_generator(complex_nested))
    
    print(f"Original: {complex_nested}")
    print(f"Flattened: {flat1}")
    assert flat1 == flat2 == flat3 == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    return flatten_recursive

def exercise_6_4():
    """
    DEBUG: Fix the code that modifies a list while iterating.
    Time: 5 minutes
    """
    # Broken code
    def remove_negatives_broken(numbers):
        """This will skip elements!"""
        for i, num in enumerate(numbers):
            if num < 0:
                del numbers[i]  # BAD: Modifying list during iteration
        return numbers
    
    # Test the broken version to see the issue
    test_broken = [-1, -2, 3, -4, 5, -6]
    # result = remove_negatives_broken(test_broken.copy())
    # Result would be [-2, 3, 5, -6] - WRONG! Skipped -2 and -6
    
    # Fixed solutions
    def remove_negatives_v1(numbers):
        """Use list comprehension (best)"""
        return [num for num in numbers if num >= 0]
    
    def remove_negatives_v2(numbers):
        """Iterate over copy"""
        result = numbers.copy()
        for num in numbers:  # Iterate over original
            if num < 0:
                result.remove(num)  # Modify copy
        return result
    
    def remove_negatives_v3(numbers):
        """Iterate backwards (index-safe)"""
        for i in range(len(numbers) - 1, -1, -1):
            if numbers[i] < 0:
                del numbers[i]
        return numbers
    
    def remove_negatives_v4(numbers):
        """Use filter"""
        return list(filter(lambda x: x >= 0, numbers))
    
    # Test all versions
    test_data = [-1, -2, 3, -4, 5, -6]
    
    result1 = remove_negatives_v1(test_data.copy())
    result2 = remove_negatives_v2(test_data.copy())
    result3 = remove_negatives_v3(test_data.copy())
    result4 = remove_negatives_v4(test_data.copy())
    
    print(f"Original: {test_data}")
    print(f"Fixed result: {result1}")
    assert result1 == result2 == result3 == result4 == [3, 5]
    
    return remove_negatives_v1

def exercise_6_5():
    """
    INTERVIEW: Optimize slow pandas code to use vectorized operations.
    Time: 15 minutes
    """
    # Generate test data
    np.random.seed(42)
    n = 100000
    df = pd.DataFrame({
        'category': np.random.choice(['A', 'B', 'C'], n),
        'value': np.random.randn(n) * 100,
        'quantity': np.random.randint(1, 100, n)
    })
    
    # SLOW VERSION - Iterating over rows
    def calculate_metrics_slow(df):
        """Slow version using iteration"""
        results = []
        
        for index, row in df.iterrows():
            if row['category'] == 'A':
                multiplier = 1.2
            elif row['category'] == 'B':
                multiplier = 1.5
            else:
                multiplier = 1.0
            
            adjusted_value = row['value'] * multiplier
            total = adjusted_value * row['quantity']
            
            results.append({
                'index': index,
                'adjusted_value': adjusted_value,
                'total': total
            })
        
        return pd.DataFrame(results)
    
    # FAST VERSION - Vectorized operations
    def calculate_metrics_fast(df):
        """Fast version using vectorized operations"""
        # Create multiplier column using numpy.where
        df['multiplier'] = np.where(
            df['category'] == 'A', 1.2,
            np.where(df['category'] == 'B', 1.5, 1.0)
        )
        
        # Vectorized calculations
        df['adjusted_value'] = df['value'] * df['multiplier']
        df['total'] = df['adjusted_value'] * df['quantity']
        
        return df[['adjusted_value', 'total']]
    
    # FASTEST VERSION - Using pandas methods
    def calculate_metrics_fastest(df):
        """Fastest using map for category lookup"""
        multiplier_map = {'A': 1.2, 'B': 1.5, 'C': 1.0}
        
        df['adjusted_value'] = df['value'] * df['category'].map(multiplier_map)
        df['total'] = df['adjusted_value'] * df['quantity']
        
        return df[['adjusted_value', 'total']]
    
    # Performance comparison (don't run on large data in exercises)
    import time
    
    # Test on small sample
    sample = df.head(1000).copy()
    
    # Slow version
    # start = time.time()
    # result_slow = calculate_metrics_slow(sample.copy())
    # slow_time = time.time() - start
    
    # Fast version
    start = time.time()
    result_fast = calculate_metrics_fast(sample.copy())
    fast_time = time.time() - start
    
    # Fastest version
    start = time.time()
    result_fastest = calculate_metrics_fastest(sample.copy())
    fastest_time = time.time() - start
    
    print(f"Vectorized version time: {fast_time:.4f}s")
    print(f"Map version time: {fastest_time:.4f}s")
    print("Vectorized operations are 100-1000x faster than iteration!")
    
    # Key optimization principles demonstrated:
    # 1. Avoid iterrows() - extremely slow
    # 2. Use numpy.where for conditional logic
    # 3. Use map() for lookups
    # 4. Leverage pandas built-in vectorized operations
    # 5. Avoid applying Python functions row-by-row
    
    return calculate_metrics_fastest

# ============================================================================
# MAIN EXECUTION
# ============================================================================

def run_all_exercises():
    """
    Run all exercises with timing and scoring.
    """
    exercises = [
        # Module 1
        exercise_1_1, exercise_1_2, exercise_1_3, exercise_1_4, exercise_1_5,
        # Module 2
        exercise_2_1, exercise_2_2, exercise_2_3, exercise_2_4, exercise_2_5,
        # Module 3
        exercise_3_1, exercise_3_2, exercise_3_3, exercise_3_4, exercise_3_5,
        # Module 4
        exercise_4_1, exercise_4_2, exercise_4_3, exercise_4_4, exercise_4_5,
        # Module 5
        exercise_5_1, exercise_5_2, exercise_5_3, exercise_5_4, exercise_5_5,
        # Module 6
        exercise_6_1, exercise_6_2, exercise_6_3, exercise_6_4, exercise_6_5,
    ]
    
    print("=" * 80)
    print("PYTHON ANALYTICS ENGINEERING INTERVIEW PREP - EXERCISES")
    print("=" * 80)
    print("\nTotal exercises: 60 (10 per module)")
    print("\nDifficulty distribution per module:")
    print("- Easy: 2 exercises")
    print("- Medium: 2 exercises") 
    print("- Hard: 2 exercises")
    print("- Debug: 2 exercises")
    print("- Interview: 2 exercises")
    print("\n" + "=" * 80)
    
    for i, exercise in enumerate(exercises, 1):
        module = (i - 1) // 10 + 1
        exercise_num = (i - 1) % 10 + 1
        
        if exercise_num == 1:
            print(f"\n{'=' * 40}")
            print(f"MODULE {module}")
            print(f"{'=' * 40}")
        
        print(f"\nExercise {module}.{exercise_num}: {exercise.__name__}")
        print("-" * 40)
        
        try:
            result = exercise()
            print("✓ Exercise completed")
        except Exception as e:
            print(f"✗ Error: {e}")
        
        print("-" * 40)

if __name__ == "__main__":
    # Run specific exercise for testing
    # exercise_1_1()
    
    # Or run all exercises
    # run_all_exercises()
    
    print("\nExercises file loaded successfully!")
    print("Run specific exercises: exercise_1_1(), exercise_2_3(), etc.")
    print("Run all exercises: run_all_exercises()")
