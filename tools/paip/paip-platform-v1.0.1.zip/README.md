# Python Analytics Interview Prep Platform

## Quick Start

**Fresh Install:**
```bash
# Download paip-platform-v1.0.1.zip and paip-install-v1.0.1.bat
# Run paip-install-v1.0.1.bat
# Platform installed!
```

## v1.0.1 Structure

```
python-analytics-interview-prep/
├── platform/
│   ├── tools/            # Setup scripts and utilities
│   │   ├── bootstrap.py  # Environment automation
│   │   └── docker/       # Docker environment (future)
│   └── content/          # Learning materials (exercises, patterns, curriculum)
└── study/                # YOUR workspace (never overwritten)
    ├── practice_work/    # Your solutions
    ├── notes/            # Your notes
    └── mock_interviews/  # Practice sessions
```

## What's in v1.0.1

**Development Environment:**
- User-level virtual environment at `~/.venvs/paip`
- Wing IDE auto-configuration (.wpr and .wpu generation)
- requirements.txt at repository root
- Improved bootstrap automation

**Complete Curriculum (from v1.0.0):**
- 60 exercises across 6 modules
- 20+ core pandas patterns
- Complete 8-week schedule
- Interview flashcards
- Full documentation suite
- Roadmap for upcoming features

**Platform:**
- Platform setup tools
- Learning content ready for population
- Automated environment configuration

## Getting Started

1. Run installer to set up repository structure
2. Run `python platform/tools/bootstrap.py` for environment setup
3. Explore learning materials: `platform/content/`
4. Work in `study/` directory - it's never overwritten

## Environment Setup

Bootstrap script automates:
- PowerShell/Bash profile configuration
- Environment variables (GITHUB_HOME, PATTERNS_REPO)
- Virtual environment creation
- Requirements installation
- Git configuration

## Updates

Download new releases and run install.bat.
Your work in `study/` is always preserved.
Old versions automatically moved to rollback folder.

## Migration from Previous Versions

The installer automatically detects and migrates old structures:
- Backs up old files to Downloads folder
- Extracts new v0.6.1 structure
- Preserves your study/ workspace

## Support

Review platform/tools/ for setup utilities and documentation.
