# Python for Analytics Engineering - Complete Course with Schedule
**Version:** 1.0.1-RC8

## Course Overview
**Duration:** 8 weeks (40 hours total)
**Target:** Analytics Engineers preparing for technical interviews
**Format:** Self-paced with daily assignments

## Week 1: Python Fundamentals (5 hours)

### Day 1: Data Types & Control Flow (1 hour)
- Lists, tuples, dictionaries, sets
- If/else, loops, comprehensions
- Practice: FizzBuzz, data type conversions

### Day 2: Functions & Error Handling (1 hour)
- Function definition and parameters
- Try/except blocks
- Lambda functions
- Practice: Custom data validators

### Day 3: File I/O & Path Operations (1 hour)
- Reading/writing CSV, JSON
- pathlib basics
- Practice: Data file processing

### Day 4: String Manipulation (1 hour)
- String methods
- f-strings and formatting
- Regular expressions basics
- Practice: Log file parsing

### Day 5: Review & Mini-Project (1 hour)
- Combine week's concepts
- Build a data cleaning script
- Code review practice

## Week 2: Pandas Basics (5 hours)

### Day 1: DataFrames & Series (1 hour)
- Creating DataFrames
- Selecting columns/rows
- Basic indexing
- Practice: Load and explore datasets

### Day 2: Filtering & Sorting (1 hour)
- Boolean indexing
- Query method
- sort_values, sort_index
- Practice: Customer segmentation

### Day 3: Missing Data (1 hour)
- isna, fillna, dropna
- Forward fill, backward fill
- Practice: Clean messy datasets

### Day 4: Groupby Basics (1 hour)
- Simple aggregations
- Multiple aggregations
- Named aggregations
- Practice: Sales analysis

### Day 5: Review & Mini-Project (1 hour)
- Combine filtering, grouping, aggregation
- Build a sales report
- Performance comparison

## Week 3: Advanced Pandas (5 hours)

### Day 1: Joins & Merges (1 hour)
- merge vs join
- Inner, outer, left, right joins
- Handling duplicates
- Practice: Customer-order analysis

### Day 2: Window Functions (1 hour)
- rolling, expanding
- shift, diff
- Practice: Time series analysis

### Day 3: Apply & Custom Functions (1 hour)
- apply, map, applymap
- When to use each
- Vectorization vs apply
- Practice: Custom transformations

### Day 4: MultiIndex & Pivot (1 hour)
- set_index, reset_index
- pivot_table, melt
- Practice: Reshaping data

### Day 5: Review & Mini-Project (1 hour)
- Complex data transformation pipeline
- Join multiple datasets
- Pivot and aggregate

## Week 4: Data Manipulation Patterns (5 hours)

### Day 1: Top N by Group (1 hour)
- sort_values + groupby + head
- rank within groups
- Practice: Top products per category

### Day 2: Deduplication (1 hour)
- drop_duplicates strategies
- Keep first vs last vs custom
- Practice: Customer deduplication

### Day 3: Date/Time Operations (1 hour)
- pd.to_datetime
- dt accessor
- Date arithmetic
- Practice: Event timeline analysis

### Day 4: String Operations (1 hour)
- str accessor
- Extract, replace, split
- Practice: Parse product codes

### Day 5: Review & Mini-Project (1 hour)
- E-commerce data analysis
- Combine all week's patterns
- Optimize for performance

## Week 5: SQL for Analysts (5 hours)

### Day 1: SELECT & WHERE (1 hour)
- Basic queries
- Filtering conditions
- LIKE, IN, BETWEEN
- Practice: Query exercise datasets

### Day 2: JOINs (1 hour)
- INNER, LEFT, RIGHT, FULL
- Multiple joins
- Self joins
- Practice: Multi-table queries

### Day 3: Aggregations (1 hour)
- GROUP BY
- HAVING
- COUNT, SUM, AVG, MIN, MAX
- Practice: Summary statistics

### Day 4: Window Functions (1 hour)
- ROW_NUMBER, RANK, DENSE_RANK
- PARTITION BY
- Running totals
- Practice: Ranking queries

### Day 5: Review & Mini-Project (1 hour)
- Complex analytical queries
- Subqueries and CTEs
- Query optimization

## Week 6: Integration & Workflows (5 hours)

### Day 1: Pandas ↔ SQL (1 hour)
- read_sql, to_sql
- Query construction
- Practice: Database operations

### Day 2: Data Validation (1 hour)
- Schema validation
- Data quality checks
- Assert statements
- Practice: Build validators

### Day 3: ETL Patterns (1 hour)
- Extract, Transform, Load
- Incremental updates
- Practice: Simple ETL pipeline

### Day 4: Error Handling & Logging (1 hour)
- Try/except in pipelines
- Logging best practices
- Practice: Robust data processing

### Day 5: Review & Mini-Project (1 hour)
- End-to-end data pipeline
- Error handling
- Logging and monitoring

## Week 7: Performance & Testing (5 hours)

### Day 1: Performance Optimization (1 hour)
- Vectorization
- Memory optimization
- Avoid iteration
- Practice: Speed up slow code

### Day 2: Profiling (1 hour)
- timeit, cProfile
- Memory profilers
- Practice: Identify bottlenecks

### Day 3: Unit Testing (1 hour)
- pytest basics
- Test data transformations
- Practice: Write test suite

### Day 4: Code Organization (1 hour)
- Functions vs classes
- Module structure
- Practice: Refactor messy code

### Day 5: Review & Mini-Project (1 hour)
- Optimize and test pipeline
- Performance benchmarks
- Code review

## Week 8: Interview Preparation (10 hours)

### Day 1-2: Pattern Practice (4 hours)
- Top N by group variations
- Join scenarios
- Aggregation challenges
- Deduplication edge cases

### Day 3-4: SQL Practice (3 hours)
- Complex joins
- Window function problems
- Subquery exercises

### Day 5-7: Mock Interviews (3 hours)
- Timed coding challenges
- Explain your approach
- Code review feedback
- Performance optimization

## Daily Study Routine

**Recommended Schedule:**
- 30 min: Review previous day
- 30 min: New concept learning
- 30 min: Coding practice
- 30 min: Pattern recognition

**Total:** 1 hour/day weekdays, catch-up on weekends

## Practice Datasets

All available in `platform/content/data/`:
- customers.csv
- orders.csv
- products.csv
- sales_transactions.csv
- web_logs.csv

## Assessment Milestones

**Week 2:** Basic pandas proficiency test
**Week 4:** Pattern recognition quiz
**Week 6:** ETL pipeline project
**Week 8:** Mock interview performance

## Success Metrics

By end of course, you should:
- Write efficient pandas code for common patterns
- Translate business questions to SQL
- Optimize slow data operations
- Handle edge cases gracefully
- Explain your code clearly

## Resources

- Platform exercises: `platform/content/src/`
- Pattern library: `platform/content/patterns/`
- Quick reference: `platform/content/docs/quick_reference.md`
- Interview tips: `platform/content/docs/talking_points.md`
