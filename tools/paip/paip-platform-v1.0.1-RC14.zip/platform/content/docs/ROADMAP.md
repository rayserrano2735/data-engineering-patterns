# PAIP Platform Roadmap
**Version:** 1.0.1-RC14

## Current Release: v1.0.0
First complete release with full curriculum, exercises, patterns, and documentation.

---

## In Progress

### v1.0.1-RC14 - Git Tracking Fix
**Target:** Current release candidate
**Status:** Building

**Goals:**
- Fix .gitignore to properly track study/ content

**RC14 Fixes:**
- ✅ .gitignore removes study content exclusions
- ✅ .gitignore tracks .wpr, ignores only .wpu
- ✅ Study workspace content now tracked in git
- ✅ Open-Wing PowerShell function for easy Wing launch
- ✅ Desktop shortcut created automatically (prompts in interactive mode)

**Root Cause Analysis:**
- RC13 had old .gitignore from uploaded repo
- Still excluded study/practice_work/*, study/notes/*, study/mock_interviews/*
- Still ignored *.wpr (should track project settings)  
- Git status doesn't show new files created in study/

**From RC13 (All Fixes Carried Forward):**
- ✅ Removed proj.env-vars from .wpu
- ✅ Wing inherits PYTHONPATH from PowerShell
- ✅ Bootstrap deletes old .wpu before creating new
- ✅ Wing Python shell and imports working
- ✅ Exercise execution and debugging working

**QA Status:** Pending testing

---

### v1.0.1-RC14 (Rejected)
**Status:** Failed QA - git tracking broken

**Why Rejected:**
- Git not tracking files created in study/practice_work/
- **ROOT CAUSE:** .gitignore had old RC7-RC9 exclusion patterns
- .gitignore excludes study/practice_work/* (should track content since RC10)
- .gitignore excludes *.wpr (should track project file since RC11)

**What Worked:**
- Wing Python shell starts successfully
- Imports work: `from src.patterns_and_gotchas import CorePatterns`
- Exercise execution works
- Debugging works in Wing

**What Failed:**
- Git tracking of study workspace content

**QA Status:** Failed - git tracking

---

### v1.0.1-RC12 (Rejected)
**Status:** Failed QA - Wing IDE broken
- Wing IDE shows "Error executing command .internal.proj.view_project_properties"
- Wing IDE shows "Error executing command .internal.proj.show_python_environment"
- Wing cannot start Python shell
- **ROOT CAUSE:** proj.env-vars in .wpu breaks Wing 11 internal commands
- PowerShell profile correctly has PYTHONPATH
- .wpu and .wpr files generated
- Python works fine from command line
- Import works in CLI: `from src.patterns_and_gotchas import CorePatterns`

**QA Status:** Failed - Wing IDE unusable

---

### v1.0.1-RC11 (Rejected)
**Status:** Failed QA - profile not updated

**Why Rejected:**
- Bootstrap reported "PowerShell profile already configured" and skipped update
- **ROOT CAUSE:** Early return on line 134-136 if PAIP_HOME found in profile
- Profile had old RC7-RC10 config without PYTHONPATH
- Bootstrap claimed success but didn't write PYTHONPATH
- ✅ PowerShell $PROFILE detection (OneDrive support)
- ✅ PAIP_HOME environment variable
- ✅ Full installer logging to install.log
- ✅ requirements.txt in manual git add command
- ✅ VC copy filename corrected
- ✅ Version headers on all documentation

**QA Status:** Testing in progress

**QA Findings:**
- **CRITICAL:** .gitignore excludes study/ content - student work not tracked by git. Protection mechanism should be installer only replaces platform/, not gitignore exclusion
- **CRITICAL:** Import fails - proj.pypath present in .wpr but missing __init__.py in platform/content/src/ prevents Python from treating it as a package
- **ROOT CAUSE:** platform/content/src/ needs __init__.py file for imports to work

**Enhancement Ideas:**

### v1.0.1-RC8 (Rejected)
**Status:** Failed QA - critical import bug

**Why Rejected:**
- Installer prompts not visible (logging captured interactive input)
- **CRITICAL:** Imports failed - bootstrap .wpr generation used f-string incorrectly, PYTHONPATH lines not written
- Bootstrap reported success but generated incomplete .wpr file

---

## Planned Features

### v1.1.0 - Active Learning: Pattern Recognition Drills
**Priority:** P1
**Estimated Effort:** Medium

**Problem:** Passive flashcard review doesn't build pattern recognition under pressure

**Solution:**
- CLI-based timed drills (90 seconds per problem)
- Random problem statements from flashcard pool
- Pattern identification before solution reveal
- Progress tracking (JSON-based statistics)
- Focus on weak areas automatically

**Success Metrics:**
- Student can identify correct pattern in <30 seconds
- 80%+ accuracy on random drill sets

---

### v1.2.0 - Active Learning: Code Validation
**Priority:** P2
**Estimated Effort:** High

**Features:**
- Skeleton code validation (did you use the right approach?)
- Timed full solution implementation
- Performance benchmarking against optimal solutions
- Automated code review (common mistakes detection)

**Dependencies:**
- v1.1.0 drill infrastructure
- Code execution sandbox
- Test case framework

---

### v1.3.0 - Interview Simulator
**Priority:** P3
**Estimated Effort:** Very High

**Features:**
- Real-time interview with Claude as interviewer
- Different interviewer personalities (supportive, challenging, etc.)
- Live code review and feedback
- Communication skills assessment
- Session recording and playback

**Technical Requirements:**
- Session state management
- Real-time code execution
- Structured feedback framework
- Difficulty progression system

---

## Future Considerations

### Docker Environment
**Priority:** TBD
**Status:** Deferred until Wing IDE setup complete

**Rationale:** Focus on core learning workflow before containerization

### GitHub Releases Integration
**Status:** Discussed, not scheduled

**Benefits:**
- User-friendly version downloads
- Release notes on GitHub
- Binary artifact hosting

### Advanced Analytics
**Ideas for exploration:**
- Learning velocity tracking
- Weak area identification
- Personalized drill generation
- Spaced repetition scheduling

---

## Completed

### v1.0.1-RC7 (Rolled Back)
- PowerShell $PROFILE detection
- Unicode character removal
- Install log (bootstrap only)
- **Blocker:** Import errors (no PYTHONPATH in .wpr)

### v1.0.0 - Complete Curriculum (Released)
- 60 exercises across 6 modules
- 20+ core pandas patterns
- 8-week course schedule
- Full documentation suite
- Flashcard library

### v0.6.x - Platform Architecture
- Two-tier structure (platform/study split)
- Installer with rollback
- Git integration
- Bootstrap automation foundation

---

## Contributing Ideas

Have ideas for features? Consider:
- Does it improve pattern recognition speed?
- Does it simulate real interview pressure?
- Does it provide measurable progress tracking?
- Is it maintainable long-term?

Focus areas welcome:
- Active learning techniques
- Interview simulation realism
- Progress analytics
- Performance optimization tools
