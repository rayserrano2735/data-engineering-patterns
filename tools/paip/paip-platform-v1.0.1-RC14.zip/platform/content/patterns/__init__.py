"""Pattern library."""
