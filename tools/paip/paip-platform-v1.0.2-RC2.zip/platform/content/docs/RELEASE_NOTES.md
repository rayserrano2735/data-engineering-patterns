# Release Notes

## v1.0.1-RC14 (Current)

**Released:** October 5, 2025

### Critical Fix

**Git Tracking:**
- Fixed .gitignore to track study/ content (RC10+ behavior)
- Removed study/practice_work/*, study/notes/*, study/mock_interviews/* exclusions
- Changed *.wpr exclusion to *.wpu (track project, ignore user prefs)
- Study workspace files now appear in git status

**Wing IDE Launcher:**
- Added `Open-Wing` PowerShell function to profile
- Created desktop shortcut "PAIP - Wing IDE" (silent mode default, prompts in interactive)
- Simple command to launch Wing with correct environment
- No need to remember long path to wing.exe

**Why This Matters:**
- RC13 had old .gitignore from repo upload
- Users couldn't track their practice work in git
- .wpr file would be ignored instead of tracked
- Study content should be version controlled since RC10
- Wing launcher makes daily use much easier

### From RC13 (All Fixes Carried Forward)
- Wing IDE working (no proj.env-vars in .wpu)
- PYTHONPATH inheritance from PowerShell
- Imports and debugging functional
- Bootstrap profile regeneration

### QA Notes
- Create test file in study/practice_work/
- Run `git status` - file should appear as untracked
- .wpr should be trackable, .wpu should be ignored

---

## v1.0.1-RC13 (Rejected)

**Released:** October 5, 2025
**Status:** Failed QA

### Why Rejected
- Git not tracking files created in study/practice_work/
- **ROOT CAUSE:** .gitignore had old RC7-RC9 patterns
- study/practice_work/* excluded (should track since RC10)
- *.wpr excluded (should track since RC11)

### What Worked
- Wing Python shell starts successfully
- Imports work: `from src.patterns_and_gotchas import CorePatterns`
- Exercise execution functional
- Debugging works in Wing

### What Failed
- Git tracking of study workspace content

---

## v1.0.1-RC12 (Rejected)

**Released:** October 5, 2025
**Status:** Failed QA

### Why Rejected
- Wing IDE showing "Error executing command .internal.proj.view_project_properties"
- Wing cannot open Python Environment settings
- Wing cannot start Python shell
- **ROOT CAUSE:** `proj.env-vars` in .wpu breaks Wing 11 internal commands

### What Worked
- PowerShell profile has PYTHONPATH correctly
- Python works from command line
- Imports work in CLI Python
- Bootstrap profile regeneration working

### What Failed
- Wing IDE completely broken
- All Wing internal commands fail
- Cannot test debugging or IDE features

---

## v1.0.1-RC11 (Rejected)

**Released:** October 5, 2025
**Status:** Failed QA

### Why Rejected
- Bootstrap said "PowerShell profile already configured" and skipped update
- **ROOT CAUSE:** Early return logic (lines 134-136) if PAIP_HOME found
- Profile had old configuration without PYTHONPATH
- PYTHONPATH never written despite bootstrap reporting success

---

## v1.0.1-RC10 (Rejected)

**Released:** October 5, 2025
**Status:** Failed QA

### Why Rejected
- Imports still failed despite __init__.py files present
- **ROOT CAUSE:** proj.pypath in .wpr only affects IDE features (autocomplete), not Python runtime execution
- Missing PYTHONPATH environment variable for actual imports
- .gitignore excluded .wpr files (should be tracked)

---

## v1.0.1-RC9 (Rejected)

**Released:** October 5, 2025
**Status:** Failed QA

### Why Rejected
- Import still failed despite proj.pypath being correct in .wpr
- **ROOT CAUSE:** Missing __init__.py in platform/content/src/ - Python requires this file to treat directories as packages
- .gitignore incorrectly excluded study/ content, preventing student work from being tracked

---

## v1.0.1-RC8 (Rejected)

**Released:** October 5, 2025
**Status:** Failed QA

### Why Rejected
- Installer prompts not visible - logging redirection captured interactive input
- **CRITICAL:** Bootstrap .wpr generation bug - f-string formatting issue caused proj.pypath lines not to be written
- Imports failed: `from src.patterns_and_gotchas import CorePatterns` → ModuleNotFoundError
- Bootstrap reported success but .wpr file was incomplete

---

## v1.0.1-RC7

**Released:** October 4, 2025
**Status:** Rolled back - QA incomplete

### Fixes
- PowerShell $PROFILE detection works with OneDrive
- All Unicode emoji removed from bootstrap
- Install log created (bootstrap output only)

### Blockers
- Platform content not importable (no PYTHONPATH in .wpr)
- Imports failed in Wing IDE
- Debugging untested due to import issue

---

## v1.0.1 (Target)

**Development Environment Improvements:**

**User-Level Virtual Environment:**
- venv now created at `~/.venvs/paip` instead of repo root
- Survives git clean operations
- Can be shared across multiple repo clones
- Cleaner repository structure

**Wing IDE Auto-Configuration:**
- Bootstrap generates .wpr (project file) automatically
- Bootstrap generates .wpu (user preferences) with correct Python interpreter
- Proper source path configuration (platform/content in PYTHONPATH)
- Exclusions for faster IDE performance
- No manual Wing setup required

**Platform:**
- `requirements.txt` now at repository root (standard location)
- Updated `.gitignore` for Wing backup files (*.wpr~, .wingide/)
- Improved bootstrap automation
- PAIP_HOME environment variable

**Documentation:**
- Complete GETTING_STARTED.md rewrite for automated setup
- ROADMAP.md added for feature planning
- Platform architecture updated with user-level venv rationale
- Version headers on all documentation

---

## v1.0.0

**Released:** October 3, 2025

### First Complete Release

**Content:**
- 60 exercises across 6 modules (exercises.py)
- 20+ core pandas patterns library (patterns_and_gotchas.py)
- 8-week curriculum with schedule
- 60 interview flashcards
- Complete documentation suite

**Documentation:**
- Platform architecture guide
- Getting started guide
- Course with schedule
- Quick reference
- Talking points
- Learning guide
- Release notes

**Platform:**
- Bootstrap automation script
- Installer with artifact cleanup
- Git autocrlf configuration
- Version control copy feature

**Structure:**
```
platform/
  tools/       - Bootstrap, Docker placeholder
  content/
    src/       - Exercises and patterns (populated)
    docs/      - Full documentation (7 files)
    patterns/  - Pattern library (8 files)
    data/      - Flashcards
study/         - User workspace
```

---

## v0.6.3

**Released:** October 3, 2025

### New Features
- Content subdirectories with .gitkeep files (src/, docs/, patterns/, data/)
- Artifact cleanup for brace-expansion folders
- Installation confirmation prompt

### Bug Fixes
- Fixed study folder zip artifact
- Fixed content folder zip artifacts
- Install script now removes unexpected subdirectories

### Improvements
- Complete platform/ folder replacement (no merge)
- CRLF warnings eliminated (autocrlf=false)
- Cleaner installation process

---

## Upgrade Path

### From v1.0.1-RC7 to RC8
- Download RC8 installer and zip
- Run installer
- Bootstrap now fixes Wing PYTHONPATH
- Imports will work automatically

### From v0.5.x to v1.0.1
- Download v1.0.1 installer and zip
- Run installer (auto-detects old structure)
- Old files moved to Downloads/paip-rollback-[date]
- study/ workspace preserved
- Bootstrap runs automatically

---

## Known Issues

### RC8
- None currently

### All Versions
- Bootstrap requires terminal restart to activate environment variables
- Virtual environment must be manually activated before use

---

## Future Releases

### Planned for v1.1.0
- Active learning: Pattern recognition drills
- Timed problem solving practice
- Progress tracking

### Under Consideration
- Automated testing framework
- GitHub Releases integration
- Docker environment
