# Platform Architecture v0.6.3

## Overview

Two-tier structure separating platform infrastructure from user workspace, with intelligent token management via incremental file loading.

## Directory Structure

```
python-analytics-interview-prep/
├── platform/
│   ├── tools/                # Platform infrastructure
│   │   ├── bootstrap.py      # Environment automation
│   │   └── docker/           # Docker setup (placeholder)
│   └── content/              # Learning materials
│       ├── src/              # Python exercises and patterns
│       ├── docs/             # Curriculum and guides
│       ├── patterns/         # Pattern library
│       └── data/             # Flashcards and datasets
└── study/                    # User workspace (not tracked)
    ├── practice_work/
    ├── notes/
    └── mock_interviews/
```

## Design Principles

### Separation of Concerns
- **tools/**: Platform setup, versioning, installation scripts
- **content/**: Learning materials organized by type
- **study/**: User workspace, never overwritten

### Token Management Strategy
GitHub KB integration uses per-message bundling. Strategy:
- Load files incrementally via folder checkboxes
- Unchecking prevents new loads but doesn't purge context
- Files under ~100KB load successfully per message
- Build complete context across multiple messages

### Version Control
- Platform versions tagged (v0.6.3, v0.6.4, etc.)
- tools/ and content/ version together
- study/ never tracked in git
- Install script copies itself to data-engineering-patterns repo

### Update Safety
- Installer detects old structures
- Automatic rollback to Downloads folder
- Complete platform/ replacement (not merge)
- study/ workspace always preserved
- Artifact cleanup for zip brace-expansion folders

## Installation Workflow

1. User downloads installer + zip
2. Confirmation prompt before proceeding
3. Git init with autocrlf=false (prevents CRLF warnings)
4. Old structure detection and rollback offer
5. Complete platform/ folder replacement
6. Zip extraction with artifact cleanup
7. study/ workspace creation if missing
8. Git commit and tag
9. Optional copy to version control repo

## Git Configuration

### CRLF Handling
```batch
git config core.autocrlf false
```
Prevents line ending conversion warnings on Windows.

### Artifact Cleanup
Install script removes brace-expansion artifacts:
- `study/{practice_work,notes,mock_interviews}/`
- `platform/content/{src,docs,patterns,data}/`

## Version Control Copy

After installation, script offers to copy installer and platform zip to version control repository for centralized management:
- Default: `data-engineering-patterns/tools/paip/`
- Custom path option available
- Creates directory if missing

## Release Process

1. Develop changes in platform repo
2. Update version in README.md and install script
3. Tag version: `git tag -a v0.6.X -m "Release description"`
4. Generate zip and installer
5. Test installation
6. Push to KB repo
7. (Future) Create GitHub Release with artifacts

## Token Budget Management

### Problem
KB content bundled per-message, creating size limits unrelated to conversation token budget.

### Solution
Incremental file loading:
1. Uncheck all KB folders initially
2. Check specific folders needed for task
3. Send message to load into context
4. Repeat for additional folders
5. Already-loaded content persists after unchecking

### Best Practices
- Load docs before starting work
- Keep large code files unchecked until needed
- Use direct file upload for files that won't load via KB
- Start new conversation if context becomes bloated

## Migration Path

### From v0.5.x
- Flat platform/ → tools/ + content/ split
- Automatic detection and rollback
- One-step migration via installer

### Future Updates
- Download new installer + zip
- Run installer (replaces platform/, preserves study/)
- Old platform backed up to Downloads

## Bootstrap Process

`platform/tools/bootstrap.py` automates:
- GitHub home detection
- Patterns repo discovery
- Shell profile configuration (PowerShell/Bash)
- Environment variables (GITHUB_HOME, PATTERNS_REPO, PATTERNS_TOOLS)
- Virtual environment setup
- Requirements installation
- Git configuration
- Wing IDE detection

## Known Issues

### KB File Loading
- Some files don't load despite being in repo and checked
- No clear size limit documentation
- Workaround: Direct file upload to chat

### Zip Artifacts
Brace expansion in bash creates unwanted folders:
- Created: `{practice_work,notes,mock_interviews}/`
- Install script cleans these automatically

## Future Enhancements

- Docker environment setup
- GitHub Releases for version downloads
- Automated testing of install script
- Context management tools
- Better KB integration or alternative solutions
