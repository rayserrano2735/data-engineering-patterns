# Getting Started

## Installation

1. Download `paip-install-v0.6.3.bat` and `paip-platform-v0.6.3.zip`
2. Run the installer
3. Confirm installation when prompted
4. Choose installation location (default: Dropbox/Projects/GitHub or GitHub folder)
5. Allow old structure rollback if detected

## First Steps

After installation:

1. **Review the structure**
   ```
   platform/
     tools/       - Bootstrap script, Docker setup
     content/     - Learning materials
       src/       - Exercises and patterns
       docs/      - Guides and curriculum
       patterns/  - Pattern library
       data/      - Datasets and flashcards
   study/         - Your workspace
   ```

2. **Run bootstrap (optional)**
   ```bash
   python platform/tools/bootstrap.py
   ```
   Automates environment setup, shell configuration, virtual environment creation.

3. **Start learning**
   - Browse `platform/content/docs/` for curriculum
   - Try exercises in `platform/content/src/`
   - Study patterns in `platform/content/patterns/`

4. **Work in study/**
   - Solutions: `study/practice_work/`
   - Notes: `study/notes/`
   - Interview practice: `study/mock_interviews/`

## Your Workspace

The `study/` directory:
- Never overwritten by platform updates
- Not tracked in git (except .gitkeep files)
- Safe place for all your work

## Environment Setup

### Manual Setup
1. Create virtual environment: `python -m venv venv`
2. Activate: `venv\Scripts\activate` (Windows) or `source venv/bin/activate` (Mac/Linux)
3. Install requirements: `pip install -r requirements.txt`

### Bootstrap Setup (Automated)
Runs `platform/tools/bootstrap.py` to configure:
- Shell profile (PowerShell/Bash)
- Environment variables (GITHUB_HOME, PATTERNS_REPO, PATTERNS_TOOLS)
- Virtual environment
- Git settings

## Daily Use

### Activate Environment
```bash
cd path/to/python-analytics-interview-prep
venv\Scripts\activate  # Windows
source venv/bin/activate  # Mac/Linux
```

### Run Exercises
```bash
python platform/content/src/exercises.py
```

### Practice Patterns
Work in `study/practice_work/`, commit your progress.

## Updates

To update platform:
1. Download new release files (install.bat + zip)
2. Run installer
3. Old platform backed up to Downloads/paip-rollback-[date]
4. Your study/ workspace preserved

## Common Issues

### Git CRLF Warnings
Already fixed - installer sets `core.autocrlf false`.

### Zip Artifacts
Brace-expansion folders automatically cleaned by installer.

### KB File Loading
If files won't load in Claude KB:
- Check folder is selected in KB interface
- Try unchecking/rechecking and sending message
- Upload large files directly to chat as fallback

## Troubleshooting

**Installation fails:**
- Ensure Git installed and in PATH
- Check write permissions to install location
- Review rollback folder in Downloads if needed

**Bootstrap fails:**
- Ensure Python 3.x installed
- Check virtual environment creation permissions
- Manually configure shell profile if needed

**Virtual environment issues:**
- Delete `venv/` folder and recreate
- Verify Python version compatibility
- Check requirements.txt exists

## Quick Commands

```bash
# Activate environment
venv\Scripts\activate

# Run exercises
python platform/content/src/exercises.py

# Install new packages
pip install package-name
pip freeze > requirements.txt

# Git workflow
git add study/practice_work/
git commit -m "Completed exercise X"
git push
```

## Next Steps

1. Complete setup via bootstrap or manual configuration
2. Review `platform/content/docs/course_with_schedule.md` for curriculum
3. Read `platform/content/docs/LEARNING_GUIDE.md` for study strategies
4. Start with beginner exercises in `platform/content/src/`
